# -*- coding: utf-8 -*-
"""
gui/main_window.py
=====================
الواجهة الرئيسية (Tkinter) لنظام أرصاد محطة عمران OYAR.
مفصولة عن منطق الحسابات وقاعدة البيانات (بند #32) -- كل العمليات
الفعلية تمر عبر core/*.

ملاحظة حول RTL: Tkinter لا يدعم محاذاة RTL كاملة للنصوص المختلطة مثل
بعض أنظمة العرض المتقدمة (Qt/WebView)، لذا تم اعتماد:
- محاذاة الحقول والتسميات إلى اليمين (anchor="e", justify="right").
- ترتيب الأقسام من اليمين إلى اليسار قدر الإمكان.
- إن رغب المستخدم بواجهة RTL كاملة بصرياً 100% يُنصح ببناء نسخة PyQt/PySide
  مستقبلية تستخدم نفس طبقة core/ دون أي تعديل (الفصل التام بين الطبقات
  يجعل ذلك ممكناً دون إعادة كتابة المنطق).
"""

from __future__ import annotations
import tkinter as tk
import json
from tkinter import ttk, messagebox, filedialog
from datetime import datetime, timezone

from core.database import (
    STATION_INFO, init_db, insert_observation, update_observation,
    delete_observation, search_observations, get_observation, decode_phenomena,
)
from core.calculations import compute_psychrometrics, compute_qnh, STATION_ELEVATION_FT
from core.validation import validate_observation, apply_cloud_absence_rule
from core.codes import PHENOMENA_TABLE, CLOUD_TYPES_LOW, CLOUD_TYPES_MID, CLOUD_TYPES_HIGH
from core.metar import build_metar
from core.synop import build_synop
from core.climate_report import build_daily_climate_report, render_daily_report_text
from core.forecast_min_temp import estimate_next_day_min, compute_model_performance
from core.export_excel import export_observations_to_excel
from core.export_pdf import export_text_report_to_pdf, export_table_to_pdf
from core.backup import create_backup, list_backups, restore_backup

BG = "#eef2f5"
HEADER_BG = "#1f4e78"
CALC_BG = "#fff6d8"
FONT_LABEL = ("Segoe UI", 10)
FONT_HEADER = ("Segoe UI", 14, "bold")
FONT_SECTION = ("Segoe UI", 11, "bold")


class OyarWeatherApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("نظام أرصاد محطة عمران OYAR")
        self.geometry("1180x800")
        self.configure(bg=BG)
        self.dark_mode = False

        init_db()

        self.entry_widgets = {}
        self.tab_order = []
        self.current_obs_id = None

        self._build_header()
        self._build_notebook()

    # ------------------------------------------------------------------
    def _build_header(self):
        header = tk.Frame(self, bg=HEADER_BG, height=64)
        header.pack(fill="x", side="top")
        s = STATION_INFO
        tk.Label(header, text="نظام أرصاد محطة عمران OYAR", bg=HEADER_BG, fg="white",
                 font=FONT_HEADER).pack(pady=(6, 0))
        info = f"WMO: {s['wmo_id']} | {s['lat']}°N | {s['lon']}°E | Elevation: {s['elevation_m']} m (~{STATION_ELEVATION_FT} ft)"
        tk.Label(header, text=info, bg=HEADER_BG, fg="#d9e6f2", font=("Segoe UI", 9)).pack()

    def _build_notebook(self):
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=6, pady=6)

        self.tab_entry = tk.Frame(self.nb, bg=BG)
        self.tab_records = tk.Frame(self.nb, bg=BG)
        self.tab_reports = tk.Frame(self.nb, bg=BG)
        self.tab_dashboard = tk.Frame(self.nb, bg=BG)
        self.tab_backup = tk.Frame(self.nb, bg=BG)

        self.nb.add(self.tab_entry, text="إدخال الرصد")
        self.nb.add(self.tab_records, text="إدارة السجلات")
        self.nb.add(self.tab_reports, text="التقارير")
        self.nb.add(self.tab_dashboard, text="لوحة التحكم")
        self.nb.add(self.tab_backup, text="النسخ الاحتياطي")

        self._build_entry_tab()
        self._build_records_tab()
        self._build_reports_tab()
        self._build_dashboard_tab()
        self._build_backup_tab()

    # ==================================================================
    # تبويب إدخال الرصد
    # ==================================================================
    def _field(self, parent, key, label, row, col=0, width=14, values=None, calculated=False):
        frame = tk.Frame(parent, bg=parent["bg"])
        frame.grid(row=row, column=col, sticky="e", padx=8, pady=4)
        tk.Label(frame, text=label, bg=parent["bg"], font=FONT_LABEL, anchor="e",
                 justify="right").pack(side="top", anchor="e")
        if values is not None:
            var = tk.StringVar()
            w = ttk.Combobox(frame, textvariable=var, values=values, width=width - 2, justify="right")
            w.pack(side="top")
        else:
            w = tk.Entry(frame, width=width, justify="right",
                          bg=CALC_BG if calculated else "white",
                          state="readonly" if calculated else "normal")
            w.pack(side="top")
        self.entry_widgets[key] = w
        self.tab_order.append(key)
        return w

    def _build_entry_tab(self):
        c = tk.Canvas(self.tab_entry, bg=BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.tab_entry, orient="vertical", command=c.yview)
        inner = tk.Frame(c, bg=BG)
        inner.bind("<Configure>", lambda e: c.configure(scrollregion=c.bbox("all")))
        c.create_window((0, 0), window=inner, anchor="nw")
        c.configure(yscrollcommand=scrollbar.set)
        c.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        r = 0
        # 1-2: التاريخ والوقت
        sec = tk.Label(inner, text="التاريخ والوقت (UTC)", font=FONT_SECTION, bg=BG, anchor="e")
        sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(6, 2)); r += 1
        self._field(inner, "obs_date", "التاريخ (YYYY-MM-DD)", r, 0)
        self._field(inner, "obs_time_utc", "الوقت UTC (HH:MM، 24 ساعة)", r, 1); r += 1

        # 3: الرياح
        sec = tk.Label(inner, text="الرياح", font=FONT_SECTION, bg=BG, anchor="e")
        sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(10, 2)); r += 1
        self._field(inner, "wind_dir_deg", "اتجاه الرياح (°) 000-360", r, 0)
        self._field(inner, "wind_speed_kt", "سرعة الرياح (kt)", r, 1)
        self._field(inner, "wind_run_counter", "جريان الرياح (عداد 5 أرقام)", r, 2); r += 1

        # 5: الرؤية
        sec = tk.Label(inner, text="الرؤية", font=FONT_SECTION, bg=BG, anchor="e")
        sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(10, 2)); r += 1
        self._field(inner, "visibility_km", "الرؤية الأفقية (km)", r, 0); r += 1

        # 6-7: الظواهر وحالة الطقس
        sec = tk.Label(inner, text="الظواهر الجوية وحالة الطقس", font=FONT_SECTION, bg=BG, anchor="e")
        sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(10, 2)); r += 1
        phen_labels = [f"{v['label_ar']}" for v in PHENOMENA_TABLE.values()]
        # محرر متعدد للظواهر: يمكن تسجيل أكثر من ظاهرة مع الشدة ووقت البداية/النهاية.
        phen_frame = tk.Frame(inner, bg=BG)
        phen_frame.grid(row=r, column=0, columnspan=3, sticky="e", padx=8, pady=4)
        tk.Label(phen_frame, text="الظواهر الجوية (متعددة)", bg=BG, font=FONT_LABEL,
                 anchor="e", justify="right").grid(row=0, column=0, columnspan=4, sticky="e")
        self.phenomena_select = ttk.Combobox(phen_frame, values=phen_labels, width=27, justify="right")
        self.phenomena_select.grid(row=1, column=0, padx=3)
        self.phenomena_intensity = ttk.Combobox(phen_frame, values=["خفيفة", "معتدلة", "شديدة"], width=9, justify="right")
        self.phenomena_intensity.set("معتدلة")
        self.phenomena_intensity.grid(row=1, column=1, padx=3)
        self.phenomena_onset = tk.Entry(phen_frame, width=8, justify="right")
        self.phenomena_onset.grid(row=1, column=2, padx=3)
        self.phenomena_onset.insert(0, "")
        self.phenomena_end = tk.Entry(phen_frame, width=8, justify="right")
        self.phenomena_end.grid(row=1, column=3, padx=3)
        tk.Label(phen_frame, text="بداية", bg=BG).grid(row=2, column=2)
        tk.Label(phen_frame, text="نهاية", bg=BG).grid(row=2, column=3)
        tk.Button(phen_frame, text="إضافة", command=self._add_phenomenon).grid(row=1, column=4, padx=4)
        self.phenomena_list = tk.Listbox(phen_frame, height=4, width=78, justify="right", exportselection=False)
        self.phenomena_list.grid(row=3, column=0, columnspan=5, pady=(5, 2), sticky="e")
        tk.Button(phen_frame, text="حذف المحدد", command=self._remove_phenomenon).grid(row=4, column=4, sticky="e")
        self.entry_widgets["phenomena_select"] = self.phenomena_select
        self.tab_order.append("phenomena_select")
        self._field(inner, "weather_state", "حالة الطقس العامة", r, 3, width=20,
                     values=["صافٍ", "غائم جزئياً", "غائم", "ممطر", "عاصف", "ضبابي"]); r += 1

        # 8: الضغط
        sec = tk.Label(inner, text="الضغط الجوي", font=FONT_SECTION, bg=BG, anchor="e")
        sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(10, 2)); r += 1
        self._field(inner, "pressure_station_hpa", "الضغط من الباروغراف (hPa)", r, 0); r += 1

        # 9: درجات الحرارة والحسابات
        sec = tk.Label(inner, text="درجات حرارة الهواء", font=FONT_SECTION, bg=BG, anchor="e")
        sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(10, 2)); r += 1
        self._field(inner, "temp_dry_c", "الحرارة الجافة (°C)", r, 0)
        self._field(inner, "temp_wet_c", "الحرارة المبللة (°C)", r, 1)
        calc_btn = tk.Button(inner, text="احسب (نقطة الندى / RH / QNH)", command=self._run_calculations,
                              bg="#2e7d32", fg="white")
        calc_btn.grid(row=r, column=2, sticky="e", padx=8); r += 1

        self._field(inner, "dew_point_c", "نقطة الندى (°C) - محسوب تلقائياً", r, 0, calculated=True)
        self._field(inner, "rh_pct", "الرطوبة النسبية (%) - محسوب تلقائياً", r, 1, calculated=True)
        self._field(inner, "vapor_pressure_hpa", "ضغط بخار الماء (hPa) - محسوب تلقائياً", r, 2, calculated=True)
        self._field(inner, "qnh_hpa", "QNH (hPa) - محسوب تلقائياً", r, 3, calculated=True); r += 1

        # 10: العظمى والصغرى
        sec = tk.Label(inner, text="درجات الحرارة القصوى والدنيا (آخر 24 ساعة)", font=FONT_SECTION, bg=BG, anchor="e")
        sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(10, 2)); r += 1
        self._field(inner, "tmax_c", "العظمى (°C)", r, 0)
        self._field(inner, "tmax_time_utc", "وقت العظمى (HH:MM)", r, 1)
        self._field(inner, "tmin_c", "الصغرى (°C)", r, 2)
        self._field(inner, "tmin_time_utc", "وقت الصغرى (HH:MM)", r, 3); r += 1

        # 11: التربة
        sec = tk.Label(inner, text="درجة حرارة التربة", font=FONT_SECTION, bg=BG, anchor="e")
        sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(10, 2)); r += 1
        self._field(inner, "soil_temp_5cm", "عمق 5 سم (°C)", r, 0)
        self._field(inner, "soil_temp_10cm", "عمق 10 سم (°C)", r, 1)
        self._field(inner, "soil_temp_20cm", "عمق 20 سم (°C)", r, 2); r += 1

        # 12: السحب
        for level, name in [("cloud_total", "السحب الكلية"), ("cloud_low", "السحب المنخفضة"),
                             ("cloud_mid", "السحب المتوسطة"), ("cloud_high", "السحب العالية")]:
            sec = tk.Label(inner, text=name, font=FONT_SECTION, bg=BG, anchor="e")
            sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(10, 2)); r += 1
            self._field(inner, f"{level}_octas", "الكمية (Octas 0-8)", r, 0)
            if level != "cloud_total":
                types = {"cloud_low": CLOUD_TYPES_LOW, "cloud_mid": CLOUD_TYPES_MID,
                         "cloud_high": CLOUD_TYPES_HIGH}[level]
                self._field(inner, f"{level}_type", "النوع", r, 1, width=12, values=types)
                self._field(inner, f"{level}_base_ft", "ارتفاع القاعدة (ft)", r, 2)
                self._field(inner, f"{level}_dir_deg", "الاتجاه (°)", r, 3)
            r += 1

        # 14: الأمطار
        sec = tk.Label(inner, text="الأمطار", font=FONT_SECTION, bg=BG, anchor="e")
        sec.grid(row=r, column=0, columnspan=4, sticky="e", pady=(10, 2)); r += 1
        self._field(inner, "rainfall_mm", "كمية الأمطار (mm)", r, 0); r += 1

        # أزرار الحفظ
        btns = tk.Frame(inner, bg=BG)
        btns.grid(row=r, column=0, columnspan=4, pady=16, sticky="e")
        tk.Button(btns, text="حفظ السجل (Ctrl+S)", bg="#1f4e78", fg="white", width=18,
                  command=self._save_observation).pack(side="right", padx=6)
        tk.Button(btns, text="سجل جديد (Ctrl+N)", width=14, command=self._clear_form).pack(side="right", padx=6)
        tk.Button(btns, text="إلغاء (Esc)", width=10, command=self._clear_form).pack(side="right", padx=6)

        # اختصارات لوحة المفاتيح وترتيب Tab
        self._setup_tab_order()
        self.bind("<Control-s>", lambda e: self._save_observation())
        self.bind("<Control-n>", lambda e: self._clear_form())
        self.bind("<Escape>", lambda e: self._clear_form())

    def _setup_tab_order(self):
        widgets = [self.entry_widgets[k] for k in self.tab_order if k in self.entry_widgets]
        for i, w in enumerate(widgets):
            nxt = widgets[(i + 1) % len(widgets)]
            w.bind("<Tab>", lambda e, n=nxt: (n.focus_set(), "break"))

    def _get_float(self, key):
        try:
            v = self.entry_widgets[key].get().strip()
            return float(v) if v else None
        except ValueError:
            return None

    def _get_str(self, key):
        v = self.entry_widgets[key].get().strip()
        return v if v else None

    def _set_calculated(self, key, value):
        w = self.entry_widgets[key]
        w.configure(state="normal")
        w.delete(0, tk.END)
        w.insert(0, str(value))
        w.configure(state="readonly")

    def _run_calculations(self):
        dry = self._get_float("temp_dry_c")
        wet = self._get_float("temp_wet_c")
        pressure = self._get_float("pressure_station_hpa")

        if dry is None or wet is None:
            messagebox.showwarning("تنبيه", "أدخل الحرارة الجافة والمبللة أولاً")
            return
        if pressure is None:
            messagebox.showwarning("تنبيه", "أدخل الضغط الجوي من الباروغراف أولاً")
            return
        try:
            r = compute_psychrometrics(dry, wet, pressure)
            self._set_calculated("dew_point_c", r["dew_point_c"])
            self._set_calculated("rh_pct", r["relative_humidity_pct"])
            self._set_calculated("vapor_pressure_hpa", r["vapor_pressure_hpa"])

            q = compute_qnh(pressure, STATION_INFO["elevation_m"], dry)
            self._set_calculated("qnh_hpa", q["qnh_rounded_hpa"])
        except ValueError as e:
            messagebox.showerror("خطأ في الحساب", str(e))

    def _collect_form_data(self) -> dict:
        data = {
            "obs_date": self._get_str("obs_date"),
            "obs_time_utc": self._get_str("obs_time_utc"),
            "wind_dir_deg": self._get_float("wind_dir_deg"),
            "wind_speed_kt": self._get_float("wind_speed_kt"),
            "wind_run_counter": self._get_str("wind_run_counter"),
            "visibility_km": self._get_float("visibility_km"),
            "phenomena_json": None,
            "weather_state": self._get_str("weather_state"),
            "pressure_station_hpa": self._get_float("pressure_station_hpa"),
            "temp_dry_c": self._get_float("temp_dry_c"),
            "temp_wet_c": self._get_float("temp_wet_c"),
            "dew_point_c": self._get_float("dew_point_c"),
            "rh_pct": self._get_float("rh_pct"),
            "vapor_pressure_hpa": self._get_float("vapor_pressure_hpa"),
            "tmax_c": self._get_float("tmax_c"),
            "tmax_time_utc": self._get_str("tmax_time_utc"),
            "tmin_c": self._get_float("tmin_c"),
            "tmin_time_utc": self._get_str("tmin_time_utc"),
            "soil_temp_5cm": self._get_float("soil_temp_5cm"),
            "soil_temp_10cm": self._get_float("soil_temp_10cm"),
            "soil_temp_20cm": self._get_float("soil_temp_20cm"),
            "cloud_total_octas": self._get_float("cloud_total_octas"),
            "cloud_low_octas": self._get_float("cloud_low_octas"),
            "cloud_low_type": self._get_str("cloud_low_type"),
            "cloud_low_base_ft": self._get_float("cloud_low_base_ft"),
            "cloud_low_dir_deg": self._get_float("cloud_low_dir_deg"),
            "cloud_mid_octas": self._get_float("cloud_mid_octas"),
            "cloud_mid_type": self._get_str("cloud_mid_type"),
            "cloud_mid_base_ft": self._get_float("cloud_mid_base_ft"),
            "cloud_mid_dir_deg": self._get_float("cloud_mid_dir_deg"),
            "cloud_high_octas": self._get_float("cloud_high_octas"),
            "cloud_high_type": self._get_str("cloud_high_type"),
            "cloud_high_base_ft": self._get_float("cloud_high_base_ft"),
            "cloud_high_dir_deg": self._get_float("cloud_high_dir_deg"),
            "rainfall_mm": self._get_float("rainfall_mm"),
            "qnh_hpa": self._get_float("qnh_hpa"),
        }
        phenomena = getattr(self, "_phenomena_items", [])
        data["phenomena_json"] = json.dumps(phenomena, ensure_ascii=False) if phenomena else None

        for k in ["cloud_total_octas", "cloud_low_octas", "cloud_mid_octas", "cloud_high_octas"]:
            if data[k] is not None:
                data[k] = int(data[k])
        return data

    def _save_observation(self):
        data = self._collect_form_data()
        data = apply_cloud_absence_rule(data)
        errors = validate_observation(data)
        if errors:
            messagebox.showerror("أخطاء في البيانات", "\n".join(errors))
            return
        try:
            if self.current_obs_id:
                update_observation(self.current_obs_id, data)
                messagebox.showinfo("تم", f"تم تحديث السجل رقم {self.current_obs_id}")
            else:
                new_id = insert_observation(data)
                self.current_obs_id = new_id
                messagebox.showinfo("تم", f"تم حفظ السجل برقم {new_id}")
            self._refresh_records()
            self._refresh_dashboard()
        except Exception as e:
            messagebox.showerror("خطأ", f"فشل الحفظ: {e}")

    def _add_phenomenon(self):
        label = self.phenomena_select.get().strip()
        if not label:
            messagebox.showwarning("تنبيه", "اختر ظاهرة جوية أولاً")
            return
        key = next((k for k, v in PHENOMENA_TABLE.items() if v["label_ar"] == label), None)
        if not key:
            messagebox.showerror("خطأ", "الظاهرة المختارة غير موجودة في جدول الأكواد")
            return
        intensity_map = {"خفيفة": "light", "معتدلة": "moderate", "شديدة": "heavy"}
        intensity_label = self.phenomena_intensity.get() or "معتدلة"
        onset = self.phenomena_onset.get().strip() or None
        end = self.phenomena_end.get().strip() or None
        for name, value in (("وقت البداية", onset), ("وقت النهاية", end)):
            if value:
                try:
                    datetime.strptime(value, "%H:%M")
                except ValueError:
                    messagebox.showerror("خطأ", f"{name} يجب أن يكون HH:MM")
                    return
        item = {"key": key, "intensity": intensity_map.get(intensity_label, "moderate")}
        if onset: item["onset"] = onset
        if end: item["end"] = end
        if not hasattr(self, "_phenomena_items"):
            self._phenomena_items = []
        # منع التكرار لنفس الظاهرة مع نفس الفترة والشدة.
        if item in self._phenomena_items:
            return
        self._phenomena_items.append(item)
        self._refresh_phenomena_list()
        self.phenomena_select.set("")
        self.phenomena_onset.delete(0, tk.END)
        self.phenomena_end.delete(0, tk.END)

    def _remove_phenomenon(self):
        sel = self.phenomena_list.curselection()
        if not sel:
            return
        del self._phenomena_items[sel[0]]
        self._refresh_phenomena_list()

    def _refresh_phenomena_list(self):
        self.phenomena_list.delete(0, tk.END)
        labels = {"light": "خفيفة", "moderate": "معتدلة", "heavy": "شديدة"}
        for item in getattr(self, "_phenomena_items", []):
            info = PHENOMENA_TABLE.get(item.get("key"), {})
            text = info.get("label_ar", item.get("key", ""))
            text += f" — {labels.get(item.get('intensity'), item.get('intensity', ''))}"
            if item.get("onset"): text += f" | بداية {item['onset']}"
            if item.get("end"): text += f" | نهاية {item['end']}"
            self.phenomena_list.insert(tk.END, text)

    def _clear_form(self):
        self._phenomena_items = []
        self._refresh_phenomena_list()
        self.phenomena_select.set("")
        self.phenomena_intensity.set("معتدلة")
        self.phenomena_onset.delete(0, tk.END)
        self.phenomena_end.delete(0, tk.END)
        for k, w in self.entry_widgets.items():
            if isinstance(w, ttk.Combobox):
                w.set("")
            else:
                state = w["state"]
                w.configure(state="normal")
                w.delete(0, tk.END)
                if state == "readonly":
                    w.configure(state="readonly")
        self.current_obs_id = None

    # ==================================================================
    # تبويب إدارة السجلات
    # ==================================================================
    def _build_records_tab(self):
        top = tk.Frame(self.tab_records, bg=BG)
        top.pack(fill="x", padx=8, pady=8)

        tk.Label(top, text="من تاريخ:", bg=BG).pack(side="right", padx=4)
        self.rec_date_from = tk.Entry(top, width=12); self.rec_date_from.pack(side="right")
        tk.Label(top, text="إلى تاريخ:", bg=BG).pack(side="right", padx=4)
        self.rec_date_to = tk.Entry(top, width=12); self.rec_date_to.pack(side="right")
        tk.Button(top, text="بحث", command=self._refresh_records).pack(side="right", padx=8)
        tk.Button(top, text="تصدير Excel", bg="#2e7d32", fg="white",
                  command=self._export_records_excel).pack(side="left", padx=4)
        tk.Button(top, text="تصدير PDF", bg="#2e7d32", fg="white",
                  command=self._export_records_pdf).pack(side="left", padx=4)
        tk.Button(top, text="حذف المحدد", bg="#c62828", fg="white",
                  command=self._delete_selected_record).pack(side="left", padx=4)
        tk.Button(top, text="تحميل للتعديل", command=self._load_selected_for_edit).pack(side="left", padx=4)

        cols = ("id", "obs_date", "obs_time_utc", "temp_dry_c", "rh_pct", "pressure_station_hpa", "wind_speed_kt")
        self.tree = ttk.Treeview(self.tab_records, columns=cols, show="headings", height=22)
        headings = {"id": "رقم", "obs_date": "التاريخ", "obs_time_utc": "الوقت UTC",
                    "temp_dry_c": "الحرارة (°C)", "rh_pct": "الرطوبة (%)",
                    "pressure_station_hpa": "الضغط (hPa)", "wind_speed_kt": "الرياح (kt)"}
        for c in cols:
            self.tree.heading(c, text=headings[c])
            self.tree.column(c, width=120, anchor="center")
        self.tree.pack(fill="both", expand=True, padx=8, pady=8)

    def _refresh_records(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        d1 = self.rec_date_from.get().strip() or None
        d2 = self.rec_date_to.get().strip() or None
        rows = search_observations(date_from=d1, date_to=d2)
        self._last_records = rows
        for r in rows:
            self.tree.insert("", "end", values=(r["id"], r["obs_date"], r["obs_time_utc"],
                                                  r.get("temp_dry_c"), r.get("rh_pct"),
                                                  r.get("pressure_station_hpa"), r.get("wind_speed_kt")))

    def _selected_record_id(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return int(self.tree.item(sel[0])["values"][0])

    def _delete_selected_record(self):
        rid = self._selected_record_id()
        if not rid:
            messagebox.showwarning("تنبيه", "اختر سجلاً أولاً")
            return
        if messagebox.askyesno("تأكيد الحذف", f"هل تريد حذف السجل رقم {rid}؟ لا يمكن التراجع."):
            delete_observation(rid)
            self._refresh_records()

    def _load_selected_for_edit(self):
        rid = self._selected_record_id()
        if not rid:
            return
        obs = get_observation(rid)
        self.current_obs_id = rid
        stored_phenomena = decode_phenomena(obs)
        self._phenomena_items = [dict(item) for item in stored_phenomena if isinstance(item, dict)]
        self._refresh_phenomena_list()
        self.entry_widgets["phenomena_select"].set("")
        for k, w in self.entry_widgets.items():
            if k in obs and obs[k] is not None:
                if isinstance(w, ttk.Combobox):
                    if k != "phenomena_select":
                        w.set(str(obs[k]))
                else:
                    state = w["state"]
                    w.configure(state="normal")
                    w.delete(0, tk.END)
                    w.insert(0, str(obs[k]))
                    if state == "readonly":
                        w.configure(state="readonly")
        self.nb.select(self.tab_entry)

    def _export_records_excel(self):
        rows = getattr(self, "_last_records", None) or search_observations()
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")])
        if path:
            export_observations_to_excel(rows, path)
            messagebox.showinfo("تم", f"تم التصدير إلى: {path}")

    def _export_records_pdf(self):
        rows = getattr(self, "_last_records", None) or search_observations()
        path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")])
        if path:
            headers = ["الرقم", "التاريخ", "الوقت", "الحرارة", "الرطوبة", "الضغط"]
            table = [[r["id"], r["obs_date"], r["obs_time_utc"], r.get("temp_dry_c"),
                      r.get("rh_pct"), r.get("pressure_station_hpa")] for r in rows]
            export_table_to_pdf("سجلات الرصد - محطة عمران OYAR", headers, table, path)
            messagebox.showinfo("تم", f"تم التصدير إلى: {path}")

    # ==================================================================
    # تبويب التقارير
    # ==================================================================
    def _build_reports_tab(self):
        top = tk.Frame(self.tab_reports, bg=BG)
        top.pack(fill="x", padx=8, pady=8)
        tk.Button(top, text="توليد METAR (آخر رصد)", bg="#1f4e78", fg="white",
                  command=self._gen_metar).pack(side="right", padx=4)
        tk.Button(top, text="توليد SYNOP (آخر رصد)", bg="#1f4e78", fg="white",
                  command=self._gen_synop).pack(side="right", padx=4)
        tk.Button(top, text="التقرير المناخي اليومي", bg="#1f4e78", fg="white",
                  command=self._gen_daily).pack(side="right", padx=4)
        tk.Button(top, text="تقدير الصغرى للغد", bg="#6a1b9a", fg="white",
                  command=self._gen_forecast).pack(side="right", padx=4)

        self.report_text = tk.Text(self.tab_reports, height=30, wrap="word", font=("Consolas", 11))
        self.report_text.pack(fill="both", expand=True, padx=8, pady=8)

        tk.Button(self.tab_reports, text="حفظ التقرير الظاهر كـ PDF",
                  command=self._save_current_report_pdf).pack(pady=4)

    def _show_report(self, text):
        self.report_text.delete("1.0", tk.END)
        self.report_text.insert(tk.END, text)

    def _gen_metar(self):
        from core.database import get_latest_observation
        obs = get_latest_observation()
        if not obs:
            messagebox.showwarning("تنبيه", "لا توجد رصدات بعد")
            return
        obs["phenomena"] = decode_phenomena(obs)
        result = build_metar(obs)
        self._show_report(result["text"] + "\n\n(ملاحظة: CAVOK مطبّق فقط عند تحقق الشروط الرسمية)")

    def _gen_synop(self):
        from core.database import get_latest_observation
        obs = get_latest_observation()
        if not obs:
            messagebox.showwarning("تنبيه", "لا توجد رصدات بعد")
            return
        obs["phenomena"] = decode_phenomena(obs)
        result = build_synop(obs)
        self._show_report(result["text"])

    def _gen_daily(self):
        date = self.rec_date_from.get().strip() or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        report = build_daily_climate_report(date)
        self._show_report(render_daily_report_text(report))

    def _gen_forecast(self):
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        r = estimate_next_day_min(date)
        perf = compute_model_performance()
        text = (
            f"تقدير درجة الحرارة الصغرى لليوم التالي (غير رسمي)\n"
            f"الصغرى المقدرة: {r.get('predicted_min_c')} °C\n"
            f"النطاق التقديري: {r.get('range_low_c')} – {r.get('range_high_c')} °C\n"
            f"حالة النموذج: {r.get('status')}\n\n"
            f"أداء النموذج التاريخي: MAE={perf.get('mae')} RMSE={perf.get('rmse')} Bias={perf.get('bias')} (n={perf.get('n')})\n\n"
            "تنويه: هذا تقدير إحصائي محلي وليس تنبؤاً جوياً رسمياً."
        )
        self._show_report(text)

    def _save_current_report_pdf(self):
        content = self.report_text.get("1.0", tk.END).strip()
        if not content:
            return
        path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")])
        if path:
            export_text_report_to_pdf("تقرير - محطة عمران OYAR", content.split("\n"), path)
            messagebox.showinfo("تم", f"تم الحفظ: {path}")

    # ==================================================================
    # لوحة التحكم
    # ==================================================================
    def _build_dashboard_tab(self):
        self.dash_frame = tk.Frame(self.tab_dashboard, bg=BG)
        self.dash_frame.pack(fill="both", expand=True, padx=10, pady=10)
        tk.Button(self.tab_dashboard, text="تحديث", command=self._refresh_dashboard).pack(pady=4)
        self._refresh_dashboard()

    def _refresh_dashboard(self):
        for w in self.dash_frame.winfo_children():
            w.destroy()
        from core.database import get_latest_observation, get_reports
        obs = get_latest_observation()
        cards = []
        if obs:
            cards = [
                ("آخر رصد", f"{obs['obs_date']} {obs['obs_time_utc']} UTC"),
                ("الحرارة الحالية", f"{obs.get('temp_dry_c', '—')} °C"),
                ("العظمى", f"{obs.get('tmax_c', '—')} °C"),
                ("الصغرى", f"{obs.get('tmin_c', '—')} °C"),
                ("الرطوبة", f"{obs.get('rh_pct', '—')} %"),
                ("الضغط", f"{obs.get('pressure_station_hpa', '—')} hPa"),
                ("QNH", f"{obs.get('qnh_hpa', '—')} hPa"),
                ("الرياح", f"{obs.get('wind_dir_deg', '—')}° / {obs.get('wind_speed_kt', '—')} kt"),
                ("الرؤية", f"{obs.get('visibility_km', '—')} km"),
                ("الأمطار", f"{obs.get('rainfall_mm', '—')} mm"),
            ]
        else:
            cards = [("الحالة", "لا توجد رصدات بعد")]

        for i, (title, val) in enumerate(cards):
            card = tk.Frame(self.dash_frame, bg="white", relief="groove", bd=1)
            card.grid(row=i // 4, column=i % 4, padx=8, pady=8, sticky="nsew")
            tk.Label(card, text=title, bg="white", font=FONT_LABEL, fg="#555").pack(pady=(8, 2), padx=20)
            tk.Label(card, text=val, bg="white", font=("Segoe UI", 13, "bold")).pack(pady=(0, 8), padx=20)

        reports = get_reports()
        completeness = "—"
        try:
            from core.database import get_day_observations
            today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            n = len(get_day_observations(today))
            completeness = f"{n}/24 رصدة اليوم"
        except Exception:
            pass
        status_card = tk.Frame(self.dash_frame, bg="white", relief="groove", bd=1)
        status_card.grid(row=99, column=0, columnspan=4, padx=8, pady=8, sticky="ew")
        tk.Label(status_card, text=f"نسبة اكتمال الرصدات: {completeness}  |  عدد التقارير المصدرة: {len(reports)}",
                 bg="white", font=FONT_LABEL).pack(pady=8)

    # ==================================================================
    # النسخ الاحتياطي
    # ==================================================================
    def _build_backup_tab(self):
        top = tk.Frame(self.tab_backup, bg=BG)
        top.pack(fill="x", padx=10, pady=10)
        tk.Button(top, text="إنشاء نسخة احتياطية الآن", bg="#2e7d32", fg="white",
                  command=self._do_backup).pack(side="right", padx=6)
        tk.Button(top, text="استعادة من نسخة محددة", bg="#c62828", fg="white",
                  command=self._do_restore).pack(side="right", padx=6)

        self.backup_list = tk.Listbox(self.tab_backup, height=20)
        self.backup_list.pack(fill="both", expand=True, padx=10, pady=10)
        self._refresh_backup_list()

    def _refresh_backup_list(self):
        self.backup_list.delete(0, tk.END)
        for b in list_backups():
            self.backup_list.insert(tk.END, b)

    def _do_backup(self):
        try:
            path = create_backup()
            messagebox.showinfo("تم", f"تم إنشاء نسخة احتياطية:\n{path}")
            self._refresh_backup_list()
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def _do_restore(self):
        sel = self.backup_list.curselection()
        if not sel:
            messagebox.showwarning("تنبيه", "اختر نسخة احتياطية من القائمة")
            return
        path = self.backup_list.get(sel[0])
        if messagebox.askyesno("تأكيد", "سيتم استبدال قاعدة البيانات الحالية (مع أخذ نسخة أمان تلقائية). متابعة؟"):
            restore_backup(path)
            messagebox.showinfo("تم", "تمت الاستعادة بنجاح")
            self._refresh_records()
            self._refresh_dashboard()


def run_app():
    app = OyarWeatherApp()
    app.mainloop()
