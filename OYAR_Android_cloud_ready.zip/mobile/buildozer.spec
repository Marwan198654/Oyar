[app]
title = OYAR Weather
package.name = oyarweather
package.domain = org.oyar
source.dir = ..
source.include_exts = py,png,jpg,kv,atlas,json,md
source.exclude_dirs = tests,gui,.pytest_cache,__pycache__
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.api = 35
android.minapi = 23
android.archs = arm64-v8a,armeabi-v7a
android.allow_backup = True
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
