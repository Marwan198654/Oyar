# -*- coding: utf-8 -*-
"""واجهة Android لنظام OYAR Weather System باستخدام Kivy."""
import os

from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.scrollview import ScrollView
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelItem
from kivy.uix.popup import Popup

from core.metar import build_metar
from core.synop import build_synop
from core.calculations import compute_psychrometrics, compute_qnh, STATION_ELEVATION_FT


class MobileApp(App):
    title = "OYAR Weather"

    def build(self):
        # Kivy's user_data_dir is the writable Android sandbox. Set it
        # before importing core.database because DB_PATH is computed at import time.
        os.environ["OYAR_DATA_DIR"] = self.user_data_dir
        from core.database import init_db
        init_db()
        root = TabbedPanel(do_default_tab=False, tab_width=dp(150))
        root.add_widget(self.entry_tab())
        root.add_widget(self.reports_tab())
        root.add_widget(self.records_tab())
        return root

    def field(self, grid, label, key, multiline=False):
        grid.add_widget(Label(text=label, size_hint_y=None, height=dp(42), halign="right"))
        w = TextInput(multiline=multiline, size_hint_y=None, height=dp(42), halign="right")
        grid.add_widget(w)
        self.fields[key] = w
        return w

    def entry_tab(self):
        tab = TabbedPanelItem(text="الرصد")
        self.fields = {}
        scroll = ScrollView()
        grid = GridLayout(cols=2, spacing=dp(7), padding=dp(12), size_hint_y=None)
        grid.bind(minimum_height=grid.setter("height"))

        for label, key in [
            ("التاريخ UTC", "obs_date"), ("الوقت UTC", "obs_time_utc"),
            ("اتجاه الرياح °", "wind_dir_deg"), ("سرعة الرياح kt", "wind_speed_kt"),
            ("الرؤية km", "visibility_km"), ("الضغط hPa", "pressure_station_hpa"),
            ("الحرارة الجافة °C", "temp_dry_c"), ("الحرارة المبللة °C", "temp_wet_c"),
            ("العظمى °C", "tmax_c"), ("وقت العظمى", "tmax_time_utc"),
            ("الصغرى °C", "tmin_c"), ("وقت الصغرى", "tmin_time_utc"),
            ("الأمطار mm", "rainfall_mm"), ("السحب الكلية octas", "cloud_total_octas"),
            ("السحب المنخفضة octas", "cloud_low_octas"), ("نوع السحب المنخفضة", "cloud_low_type"),
            ("السحب المتوسطة octas", "cloud_mid_octas"), ("نوع السحب المتوسطة", "cloud_mid_type"),
            ("السحب العالية octas", "cloud_high_octas"), ("نوع السحب العالية", "cloud_high_type"),
        ]:
            self.field(grid, label, key)

        grid.add_widget(Label(text="حالة الطقس", size_hint_y=None, height=dp(42)))
        self.fields["weather_state"] = Spinner(text="اختر", values=("صافٍ", "غائم جزئياً", "غائم", "ممطر", "عاصف", "ضبابي"), size_hint_y=None, height=dp(42))
        grid.add_widget(self.fields["weather_state"])

        save = Button(text="حفظ الرصد", size_hint_y=None, height=dp(52))
        save.bind(on_release=lambda *_: self.save_observation())
        grid.add_widget(save); grid.add_widget(Label(text=""))
        calc = Button(text="حساب RH / نقطة الندى / QNH", size_hint_y=None, height=dp(52))
        calc.bind(on_release=lambda *_: self.calculate())
        grid.add_widget(calc); grid.add_widget(Label(text=""))

        scroll.add_widget(grid); tab.add_widget(scroll)
        return tab

    def num(self, key):
        v = self.fields[key].text.strip()
        if not v: return None
        return float(v)

    def save_observation(self):
        from core.database import insert_observation
        data = {}
        for key, widget in self.fields.items():
            if isinstance(widget, Spinner):
                value = widget.text if widget.text != "اختر" else None
            else:
                value = widget.text.strip() or None
            data[key] = value
        numeric = ["wind_dir_deg","wind_speed_kt","visibility_km","pressure_station_hpa","temp_dry_c","temp_wet_c","tmax_c","tmin_c","rainfall_mm","cloud_total_octas","cloud_low_octas","cloud_mid_octas","cloud_high_octas"]
        for key in numeric:
            if data.get(key) is not None:
                try: data[key] = float(data[key])
                except ValueError: return self.info("خطأ", f"قيمة غير صحيحة: {key}")
        data["phenomena_json"] = "[]"
        try:
            obs_id = insert_observation(data)
            self.info("تم الحفظ", f"تم حفظ الرصد رقم {obs_id}")
        except Exception as exc:
            self.info("خطأ", str(exc))

    def calculate(self):
        try:
            dry, wet, pressure = self.num("temp_dry_c"), self.num("temp_wet_c"), self.num("pressure_station_hpa")
            result = compute_psychrometrics(dry, wet)
            qnh = compute_qnh(pressure, STATION_ELEVATION_FT, dry)
            self.info("الحسابات", f"RH: {result['rh_pct']:.1f}%\nنقطة الندى: {result['dew_point_c']:.1f} °C\nQNH: {qnh:.1f} hPa")
        except Exception as exc:
            self.info("خطأ", str(exc))

    def reports_tab(self):
        tab = TabbedPanelItem(text="METAR / SYNOP")
        box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        self.report_out = TextInput(readonly=True, multiline=True, font_size=dp(16))
        b1 = Button(text="إصدار METAR لآخر رصد", size_hint_y=None, height=dp(52))
        b2 = Button(text="إصدار SYNOP لآخر رصد", size_hint_y=None, height=dp(52))
        b1.bind(on_release=lambda *_: self.make_report("metar"))
        b2.bind(on_release=lambda *_: self.make_report("synop"))
        box.add_widget(b1); box.add_widget(b2); box.add_widget(self.report_out)
        tab.add_widget(box); return tab

    def make_report(self, kind):
        from core.database import search_observations
        rows = search_observations(order_by="obs_date DESC, obs_time_utc DESC")
        if not rows: return self.info("لا توجد بيانات", "احفظ رصداً أولاً")
        obs = rows[0]
        try:
            result = build_metar(obs) if kind == "metar" else build_synop(obs)
            self.report_out.text = result["text"]
        except Exception as exc:
            self.info("خطأ", str(exc))

    def records_tab(self):
        tab = TabbedPanelItem(text="السجلات")
        box = BoxLayout(orientation="vertical", padding=dp(12))
        out = TextInput(readonly=True, multiline=True)
        btn = Button(text="تحديث السجلات", size_hint_y=None, height=dp(52))
        def refresh(*_):
            from core.database import search_observations
            rows = search_observations(order_by="obs_date DESC, obs_time_utc DESC")
            out.text = "\n".join(f"#{r['id']}  {r['obs_date']} {r['obs_time_utc']}  T={r['temp_dry_c']}  P={r['pressure_station_hpa']}" for r in rows[:100])
        btn.bind(on_release=refresh); box.add_widget(btn); box.add_widget(out); tab.add_widget(box)
        Clock.schedule_once(refresh, 0)
        return tab

    def info(self, title, message):
        Popup(title=title, content=Label(text=message), size_hint=(.88, .4)).open()


if __name__ == "__main__":
    MobileApp().run()
