import json
from core.database import decode_phenomena


def test_decode_phenomena_json():
    obs = {"id": 1, "phenomena_json": json.dumps([{"key": "rain", "intensity": "moderate"}])}
    assert decode_phenomena(obs)[0]["key"] == "rain"


def test_decode_phenomena_invalid_json_is_empty():
    assert decode_phenomena({"phenomena_json": "{bad"}) == []
