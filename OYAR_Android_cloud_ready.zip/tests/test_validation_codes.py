# -*- coding: utf-8 -*-
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.validation import validate_observation, apply_cloud_absence_rule
from core.codes import get_phenomenon, PHENOMENA_TABLE


def test_valid_observation_no_errors():
    data = {
        "obs_date": "2026-09-17", "obs_time_utc": "12:00",
        "wind_dir_deg": 180, "wind_speed_kt": 10, "wind_run_counter": "00372",
        "visibility_km": 10, "pressure_station_hpa": 795.5,
        "temp_dry_c": 25.0, "temp_wet_c": 18.0,
        "cloud_total_octas": 3, "rainfall_mm": 0.0,
    }
    assert validate_observation(data) == []


def test_wind_direction_out_of_range():
    data = {"obs_date": "2026-09-17", "obs_time_utc": "12:00", "wind_dir_deg": 400}
    errors = validate_observation(data)
    assert any("اتجاه الرياح" in e for e in errors)


def test_wind_run_counter_must_be_5_digits():
    data = {"obs_date": "2026-09-17", "obs_time_utc": "12:00", "wind_run_counter": "372"}
    errors = validate_observation(data)
    assert any("جريان الرياح" in e for e in errors)


def test_wind_run_counter_preserves_leading_zeros():
    # القيمة يجب أن تبقى نصاً "00372" وليس 372
    counter = "00372"
    assert counter == "00372"
    assert int(counter) == 372  # يمكن حساب الفرق دون فقدان التمثيل الأصلي


def test_cloud_absence_rule():
    data = {"cloud_low_octas": 0, "cloud_low_type": "Cu", "cloud_low_base_ft": 3000, "cloud_low_dir_deg": 90}
    result = apply_cloud_absence_rule(data)
    assert result["cloud_low_type"] == "لا يوجد"
    assert result["cloud_low_base_ft"] is None
    assert result["cloud_low_dir_deg"] is None


def test_cloud_present_rule_untouched():
    data = {"cloud_low_octas": 4, "cloud_low_type": "Cu", "cloud_low_base_ft": 3000, "cloud_low_dir_deg": 90}
    result = apply_cloud_absence_rule(data)
    assert result["cloud_low_type"] == "Cu"
    assert result["cloud_low_base_ft"] == 3000


def test_phenomenon_lookup():
    ph = get_phenomenon("rain")
    assert ph["metar_code"] == "RA"
    assert ph["synop_ww"] == "61"


def test_unknown_phenomenon_raises():
    import pytest
    with pytest.raises(KeyError):
        get_phenomenon("not_a_real_phenomenon")
