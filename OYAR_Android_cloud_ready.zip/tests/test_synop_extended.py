import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from core.synop import build_synop
from core.validation import validate_synop_fields

BASE = {
    "obs_date":"2026-09-17", "obs_time_utc":"12:29",
    "wind_dir_deg":180, "wind_speed_kt":12,
    "temp_dry_c":25, "dew_point_c":18,
    "pressure_station_hpa":795.5, "pressure_msl_hpa":1012.4,
    "rainfall_mm":1.5, "rainfall_period_code":"2",
    "synop_visibility_code":"90", "synop_h_code":"5",
    "cloud_total_octas":4, "cloud_low_octas":4, "cloud_low_type":"Cu",
    "cloud_mid_type":"As", "cloud_high_type":"Ci",
    "pressure_tendency_characteristic":"2", "pressure_change_3h_hpa":1.2,
    "tmax_c":27, "tmin_c":14, "rainfall_24h_mm":8.2,
}

def test_extended_synop_groups():
    r = build_synop(BASE)
    text = r["text"]
    assert "41399" in text
    assert "3" in text
    assert "37955" in text  # station pressure 795.5
    assert "40124" in text  # MSL pressure 1012.4
    assert "52012" in text
    assert "60022" in text
    assert "333" in text

def test_rounds_observation_hour():
    d = dict(BASE, obs_time_utc="12:31")
    assert build_synop(d)["header"] == "AAXX 17134"

def test_high_wind_group():
    d = dict(BASE, wind_speed_kt=120)
    text = build_synop(d)["text"]
    assert "41899" in text
    assert "00120" in text

def test_synop_field_validation():
    errors = validate_synop_fields({"synop_iw":"9", "synop_ir":"8", "synop_visibility_code":"7"})
    assert len(errors) == 3


def test_visibility_km_is_encoded_by_wmo_4377():
    for km, code in [(0.0, "00"), (0.35, "03"), (1.27, "12"), (4.99, "49"),
                     (5.0, "50"), (5.8, "50"), (6.0, "56"), (12.9, "62"),
                     (30.0, "80"), (34.9, "80"), (35.0, "81"), (49.0, "83"),
                     (70.0, "89"), (100.0, "89")]:
        d = dict(BASE)
        d.pop("synop_visibility_code", None)
        d["visibility_km"] = km
        text = build_synop(d)["text"]
        assert f"{code}" in text, (km, code, text)


def test_visibility_unused_codes_are_rejected():
    import pytest
    d = dict(BASE, synop_visibility_code="53")
    with pytest.raises(ValueError):
        build_synop(d)


def test_present_weather_multiple_phenomena_uses_highest_code():
    d = dict(BASE, phenomena=[
        {"key": "rain"},          # 61
        {"key": "snow"},          # 71
        {"key": "fog"},           # 45
    ])
    text = build_synop(d)["text"]
    assert "771" in text  # 7 + ww=71 + W1W2 unknown


def test_present_weather_code_17_precedes_20_to_49():
    d = dict(BASE, phenomena=[
        {"key": "fog"},           # 45
        {"key": "lightning"},     # 17
    ])
    text = build_synop(d)["text"]
    assert "717//" in text


def test_past_weather_selects_two_most_significant_and_avoids_present_when_possible():
    d = dict(BASE,
             phenomena=[{"key": "rain"}],
             past_phenomena=[
                 {"key": "rain"},          # W=6
                 {"key": "snow"},          # W=7
                 {"key": "thunderstorm"},  # W=9
             ])
    text = build_synop(d)["text"]
    # ww=95 for thunderstorm? No: present is rain => 61. Past picks 9 then 7.
    assert "76197" in text


def test_single_past_weather_repeats_in_w1_w2():
    d = dict(BASE, phenomena=[], past_phenomena=[{"key": "rain"}])
    text = build_synop(d)["text"]
    assert "7//66" in text


def test_no_significant_weather_omits_group():
    d = dict(BASE, phenomena=[{"key": "other"}], past_phenomena=[])
    text = build_synop(d)["text"]
    assert "7" not in text.split("333")[0].split(" ")
