# -*- coding: utf-8 -*-
"""
tests/test_calculations.py
=============================
اختبارات وحدة الحسابات الجوية (بند #31).
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest
from core.calculations import (
    compute_psychrometrics, compute_qnh, meters_to_feet, feet_to_meters,
    kt_to_ms, kt_to_kmh, STATION_ELEVATION_M, STATION_ELEVATION_FT,
)


def test_elevation_conversion():
    # 2239 m يجب أن تعطي تقريباً 7346 ft (كما ورد في المتطلبات)
    ft = meters_to_feet(2239)
    assert abs(ft - 7346) < 5, f"expected ~7346 ft, got {ft}"


def test_feet_roundtrip():
    m = 2239
    ft = meters_to_feet(m)
    back = feet_to_meters(ft)
    assert abs(back - m) < 0.5


def test_wind_unit_conversions():
    assert abs(kt_to_ms(10) - 5.14) < 0.02
    assert abs(kt_to_kmh(10) - 18.52) < 0.02


def test_psychrometrics_saturated():
    # عندما تتساوى الجافة والمبللة، يجب أن تكون الرطوبة 100% تقريباً ونقطة
    # الندى قريبة جداً من درجة الحرارة الجافة.
    r = compute_psychrometrics(20.0, 20.0, 1000.0)
    assert r["relative_humidity_pct"] > 98
    assert abs(r["dew_point_c"] - 20.0) < 0.5


def test_psychrometrics_dry_air():
    r = compute_psychrometrics(30.0, 15.0, 850.0)
    assert 0 < r["relative_humidity_pct"] < 100
    assert r["dew_point_c"] < 30.0


def test_psychrometrics_invalid_wet_greater_than_dry():
    with pytest.raises(ValueError):
        compute_psychrometrics(15.0, 20.0, 1000.0)


def test_qnh_higher_than_station_pressure():
    # QNH يجب أن يكون أعلى من ضغط المحطة دائماً لمحطة مرتفعة كـ OYAR (2239m)
    q = compute_qnh(800.0, STATION_ELEVATION_M, 25.0)
    assert q["qnh_hpa"] > 800.0
    assert q["metar_group"].startswith("Q")
    assert len(q["metar_group"]) == 5


def test_qnh_metar_group_format():
    q = compute_qnh(795.3, STATION_ELEVATION_M, 20.0)
    assert q["metar_group"][0] == "Q"
    assert q["metar_group"][1:].isdigit()


def test_qnh_sea_level_station_close_to_station_pressure():
    # لمحطة عند مستوى سطح البحر تقريباً، QNH يجب أن يقترب من ضغط المحطة
    q = compute_qnh(1013.25, 0, 15.0)
    assert abs(q["qnh_hpa"] - 1013.25) < 0.5
