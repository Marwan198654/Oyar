# -*- coding: utf-8 -*-
"""نقطة تشغيل نظام أرصاد محطة عمران OYAR."""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))


def main():
    # Buildozer launches this root main.py on Android. Keep desktop-only
    # dependencies out of the Android import path.
    if os.environ.get("ANDROID_ARGUMENT"):
        from mobile.main import MobileApp
        MobileApp().run()
        return

    from core.logging_config import setup_logging
    from core.database import init_db
    from core.scheduler import ReportScheduler

    logger = setup_logging()
    logger.info("بدء تشغيل نظام أرصاد محطة عمران OYAR")
    init_db()

    scheduler = ReportScheduler()
    scheduler.start()

    from gui.main_window import run_app
    try:
        run_app()
    finally:
        scheduler.stop()
        logger.info("إيقاف النظام")


if __name__ == "__main__":
    main()
