# -*- coding: utf-8 -*-
"""
core/database.py
==================
طبقة قاعدة البيانات المحلية (SQLite) لمحطة عمران OYAR.
مفصولة بالكامل عن الحسابات وواجهة المستخدم (بند #32).

كل التعديلات تمر عبر هذه الوحدة فقط -- لا SQL خام في الواجهة.
"""

from __future__ import annotations
import sqlite3
import os
import logging
import json
from datetime import datetime, timezone
from contextlib import contextmanager

DATA_DIR = os.environ.get("OYAR_DATA_DIR") or os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")
DB_PATH = os.path.join(DATA_DIR, "oyar_weather.db")

logger = logging.getLogger("oyar.database")

STATION_INFO = {
    "name_ar": "عمران",
    "name_code": "OYAR",
    "wmo_id": "41399",
    "lat": 15.46,
    "lon": 44.10,
    "elevation_m": 2239.0,
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS observations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    obs_date TEXT NOT NULL,              -- YYYY-MM-DD
    obs_time_utc TEXT NOT NULL,          -- HH:MM (24h, UTC) -- وقت الرصد
    wind_dir_deg INTEGER,                -- 0-360
    wind_speed_kt REAL,
    wind_run_counter TEXT,               -- 5 digits, stored as TEXT to keep leading zeros
    visibility_km REAL,
    phenomena_json TEXT,                 -- JSON list of {code, category, onset, end, intensity, note}
    weather_state TEXT,                  -- حالة الطقس العامة (نصي)
    weather_present_code TEXT,           -- كود الطقس الحالي لـ METAR (ww)
    weather_past_code TEXT,              -- كود الطقس السابق لـ SYNOP (W1W2)
    pressure_station_hpa REAL,           -- قراءة الباروغراف الأصلية
    temp_dry_c REAL,
    temp_wet_c REAL,
    dew_point_c REAL,                    -- محسوب
    rh_pct REAL,                         -- محسوب
    vapor_pressure_hpa REAL,             -- محسوب
    tmax_c REAL,
    tmax_time_utc TEXT,
    tmax_period_start TEXT,
    tmax_period_end TEXT,
    tmin_c REAL,
    tmin_time_utc TEXT,
    tmin_period_start TEXT,
    tmin_period_end TEXT,
    soil_temp_5cm REAL,
    soil_temp_10cm REAL,
    soil_temp_20cm REAL,
    cloud_total_octas INTEGER,           -- 0-8, NULL = غير متاح
    cloud_low_octas INTEGER,
    cloud_low_type TEXT,
    cloud_low_base_ft REAL,
    cloud_low_dir_deg INTEGER,
    cloud_mid_octas INTEGER,
    cloud_mid_type TEXT,
    cloud_mid_base_ft REAL,
    cloud_mid_dir_deg INTEGER,
    cloud_high_octas INTEGER,
    cloud_high_type TEXT,
    cloud_high_base_ft REAL,
    cloud_high_dir_deg INTEGER,
    rainfall_mm REAL,
    qnh_hpa REAL,                        -- محسوب، محفوظ منفصلاً عن pressure_station_hpa
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_obs_date_time ON observations(obs_date, obs_time_utc);

CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_type TEXT NOT NULL,           -- METAR / SYNOP / DAILY_CLIMATE
    report_date TEXT NOT NULL,
    period_start TEXT,
    period_end TEXT,
    issued_at_utc TEXT NOT NULL,
    issued_at_local TEXT NOT NULL,
    scheduled_at_utc TEXT,
    delay_reason TEXT,
    version_no INTEGER NOT NULL DEFAULT 1,
    content TEXT NOT NULL,               -- النص النهائي للتقرير
    superseded INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reports_type_date ON reports(report_type, report_date);

CREATE TABLE IF NOT EXISTS forecast_eval (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    forecast_date TEXT NOT NULL,         -- اليوم الذي يخص التقدير
    predicted_min_c REAL,
    range_low_c REAL,
    range_high_c REAL,
    actual_min_c REAL,
    error_c REAL,
    created_at TEXT NOT NULL
);
"""


def get_connection() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db_cursor():
    conn = get_connection()
    try:
        cur = conn.cursor()
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        logger.exception("خطأ في عملية قاعدة البيانات")
        raise
    finally:
        conn.close()


def init_db():
    with db_cursor() as cur:
        cur.executescript(SCHEMA)
    logger.info("تم تهيئة قاعدة البيانات في %s", DB_PATH)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


# ----------------------------------------------------------------------
# CRUD الرصدات
# ----------------------------------------------------------------------
def insert_observation(data: dict) -> int:
    """يدرج سجل رصد جديد ويعيد رقم السجل."""
    data = dict(data)
    ts = now_iso()
    data["created_at"] = ts
    data["updated_at"] = ts
    cols = ", ".join(data.keys())
    placeholders = ", ".join(["?"] * len(data))
    with db_cursor() as cur:
        cur.execute(f"INSERT INTO observations ({cols}) VALUES ({placeholders})", list(data.values()))
        return cur.lastrowid


def update_observation(obs_id: int, data: dict):
    data = dict(data)
    data["updated_at"] = now_iso()
    set_clause = ", ".join(f"{k} = ?" for k in data.keys())
    with db_cursor() as cur:
        cur.execute(f"UPDATE observations SET {set_clause} WHERE id = ?", list(data.values()) + [obs_id])


def delete_observation(obs_id: int):
    with db_cursor() as cur:
        cur.execute("DELETE FROM observations WHERE id = ?", (obs_id,))


def get_observation(obs_id: int):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM observations WHERE id = ?", (obs_id,))
        row = cur.fetchone()
        return dict(row) if row else None


def search_observations(date_from=None, date_to=None, obs_id=None, order_by="obs_date, obs_time_utc"):
    query = "SELECT * FROM observations WHERE 1=1"
    params = []
    if obs_id:
        query += " AND id = ?"
        params.append(obs_id)
    if date_from:
        query += " AND obs_date >= ?"
        params.append(date_from)
    if date_to:
        query += " AND obs_date <= ?"
        params.append(date_to)
    query += f" ORDER BY {order_by}"
    with db_cursor() as cur:
        cur.execute(query, params)
        return [dict(r) for r in cur.fetchall()]


def decode_phenomena(obs: dict) -> list:
    """يفك قائمة الظواهر المخزنة في phenomena_json بأمان.

    تُرجع قائمة فارغة عند غياب الحقل أو وجود JSON غير صالح، حتى لا يمنع
    تلف سجل واحد إصدار بقية التقارير.
    """
    raw = obs.get("phenomena_json") if obs else None
    if not raw:
        return []
    if isinstance(raw, list):
        return raw
    try:
        value = json.loads(raw)
        return value if isinstance(value, list) else []
    except (TypeError, ValueError, json.JSONDecodeError):
        logger.warning("تعذر فك phenomena_json للسجل %s", obs.get("id") if obs else None)
        return []


def get_latest_observation():
    with db_cursor() as cur:
        cur.execute("SELECT * FROM observations ORDER BY obs_date DESC, obs_time_utc DESC LIMIT 1")
        row = cur.fetchone()
        return dict(row) if row else None


def get_day_observations(obs_date: str):
    return search_observations(date_from=obs_date, date_to=obs_date)


# ----------------------------------------------------------------------
# CRUD التقارير
# ----------------------------------------------------------------------
def save_report(report_type, report_date, content, period_start=None, period_end=None,
                 scheduled_at_utc=None, delay_reason=None, issued_at_local=None):
    with db_cursor() as cur:
        cur.execute(
            "SELECT MAX(version_no) as v FROM reports WHERE report_type=? AND report_date=? AND period_start IS ?",
            (report_type, report_date, period_start),
        )
        row = cur.fetchone()
        version = (row["v"] or 0) + 1
        if version > 1:
            cur.execute(
                "UPDATE reports SET superseded=1 WHERE report_type=? AND report_date=? AND period_start IS ?",
                (report_type, report_date, period_start),
            )
        ts = now_iso()
        cur.execute(
            """INSERT INTO reports (report_type, report_date, period_start, period_end,
               issued_at_utc, issued_at_local, scheduled_at_utc, delay_reason,
               version_no, content, superseded, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,0,?)""",
            (report_type, report_date, period_start, period_end, ts,
             issued_at_local or ts, scheduled_at_utc, delay_reason, version, content, ts),
        )
        return cur.lastrowid


def report_exists(report_type, report_date, period_start=None):
    with db_cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) as c FROM reports WHERE report_type=? AND report_date=? AND period_start IS ? AND superseded=0",
            (report_type, report_date, period_start),
        )
        return cur.fetchone()["c"] > 0


def get_reports(report_type=None, report_date=None):
    query = "SELECT * FROM reports WHERE 1=1"
    params = []
    if report_type:
        query += " AND report_type = ?"
        params.append(report_type)
    if report_date:
        query += " AND report_date = ?"
        params.append(report_date)
    query += " ORDER BY id DESC"
    with db_cursor() as cur:
        cur.execute(query, params)
        return [dict(r) for r in cur.fetchall()]
