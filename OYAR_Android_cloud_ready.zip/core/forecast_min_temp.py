# -*- coding: utf-8 -*-
"""
core/forecast_min_temp.py
============================
تقدير إحصائي محلي (غير رسمي) لدرجة الحرارة الصغرى لليوم التالي، بند #21.

المنهجية (نموذج بسيط قابل للتحسين مع تراكم البيانات - Baseline model):
1. يجمع رصدات الساعة الأخيرة (18-24 UTC عادة أقرب مؤشر لليوم القادم) بالإضافة
   إلى صغرى الأيام السابقة المشابهة (نفس الشهر) كخط أساس مناخي.
2. يحسب انحداراً بسيطاً: صغرى الغد ≈ صغرى اليوم + تصحيح يعتمد على
   (التغير في نقطة الندى، الغيوم، الرياح عند الغروب/الليل).
   - سماء صافية + رياح خفيفة + رطوبة منخفضة  → تبريد إشعاعي أقوى (صغرى أدنى).
   - غيوم كثيفة أو رياح قوية  → تبريد أقل (صغرى أعلى، أقرب لدرجة الندى).
3. النطاق التقديري = التقدير المركزي ± الانحراف المعياري لأخطاء النموذج
   التاريخية (أو ± 1.5°C افتراضياً إذا لا توجد بيانات تقييم كافية).

هذا **ليس تنبؤاً رسمياً** ولا يعتمد نماذج عددية للطقس (NWP)، بل نموذج
إحصائي محلي بسيط. النتائج تُعرض دوماً مع تنويه بذلك (بند 21).
"""

from __future__ import annotations
import statistics
from datetime import datetime, timedelta
from core.database import search_observations, db_cursor

MIN_HISTORY_DAYS = 10  # الحد الأدنى من الأيام لاعتبار "بيانات كافية"


def _radiative_cooling_correction(last_obs: dict) -> float:
    """تصحيح تجريبي بسيط بالدرجات المئوية بناءً على الغيوم/الرياح/الرطوبة."""
    correction = 0.0
    cloud = last_obs.get("cloud_total_octas")
    wind = last_obs.get("wind_speed_kt")
    rh = last_obs.get("rh_pct")

    if cloud is not None:
        if cloud <= 2:
            correction -= 1.0   # سماء صافية => تبريد إضافي
        elif cloud >= 6:
            correction += 1.0   # غيوم كثيفة => تبريد أقل

    if wind is not None:
        if wind < 5:
            correction -= 0.5   # رياح خفيفة => تبريد إشعاعي أقوى
        elif wind > 15:
            correction += 0.5   # رياح قوية => خلط هوائي، تبريد أقل

    if rh is not None:
        if rh < 30:
            correction -= 0.5
        elif rh > 80:
            correction += 0.5

    return correction


def estimate_next_day_min(target_date: str) -> dict:
    """
    target_date: تاريخ اليوم *الحالي* (سيُقدَّر صغرى اليوم التالي له).
    """
    today_rows = search_observations(date_from=target_date, date_to=target_date)
    if not today_rows:
        return {"status": "بيانات غير كافية", "predicted_min_c": None,
                "range_low_c": None, "range_high_c": None}

    today_temps = [r["temp_dry_c"] for r in today_rows if r.get("temp_dry_c") is not None]
    if not today_temps:
        return {"status": "بيانات غير كافية", "predicted_min_c": None,
                "range_low_c": None, "range_high_c": None}
    today_min = min(today_temps)

    last_obs = max(today_rows, key=lambda r: r["obs_time_utc"])
    correction = _radiative_cooling_correction(last_obs)

    # خط أساس مناخي: متوسط صغرى نفس الشهر في السنوات/الأيام السابقة المتاحة
    dt = datetime.strptime(target_date, "%Y-%m-%d")
    month = dt.month
    with db_cursor() as cur:
        cur.execute("SELECT obs_date, MIN(temp_dry_c) as dmin FROM observations "
                    "WHERE strftime('%m', obs_date) = ? GROUP BY obs_date", (f"{month:02d}",))
        hist_rows = cur.fetchall()
    hist_mins = [r["dmin"] for r in hist_rows if r["dmin"] is not None]

    n_days = len(hist_mins)
    predicted = today_min + correction
    if hist_mins:
        climat_avg = statistics.mean(hist_mins)
        # مزج مرجّح: كلما زادت البيانات التاريخية، زاد وزن الخط المناخي قليلاً
        weight_hist = min(0.3, n_days / 100.0)
        predicted = predicted * (1 - weight_hist) + climat_avg * weight_hist

    if n_days >= MIN_HISTORY_DAYS:
        std = statistics.pstdev(hist_mins) if len(hist_mins) > 1 else 1.5
        margin = max(0.5, min(std, 3.0))
        status = "بيانات كافية"
    else:
        margin = 1.5
        status = "بيانات غير كافية (أقل من %d يوم تاريخي)" % MIN_HISTORY_DAYS

    return {
        "status": status,
        "predicted_min_c": round(predicted, 1),
        "range_low_c": round(predicted - margin, 1),
        "range_high_c": round(predicted + margin, 1),
        "history_days_used": n_days,
        "method": "Baseline: today_min + radiative-cooling correction, "
                  "blended with monthly climatological mean (not an official forecast)",
    }


def evaluate_forecast(forecast_date: str, predicted_min_c: float, range_low, range_high, actual_min_c: float):
    """يحسب خطأ التقدير بعد توفر القيمة الحقيقية، ويحفظه لتقييم MAE/RMSE/Bias لاحقاً."""
    from core.database import db_cursor, now_iso
    error = round(actual_min_c - predicted_min_c, 2)
    with db_cursor() as cur:
        cur.execute(
            """INSERT INTO forecast_eval (forecast_date, predicted_min_c, range_low_c,
               range_high_c, actual_min_c, error_c, created_at) VALUES (?,?,?,?,?,?,?)""",
            (forecast_date, predicted_min_c, range_low, range_high, actual_min_c, error, now_iso()),
        )
    return error


def compute_model_performance():
    """MAE / RMSE / Bias على كل سجلات التقييم المتوفرة."""
    with db_cursor() as cur:
        cur.execute("SELECT error_c FROM forecast_eval WHERE error_c IS NOT NULL")
        errors = [r["error_c"] for r in cur.fetchall()]
    if not errors:
        return {"status": "لا توجد بيانات تقييم بعد", "mae": None, "rmse": None, "bias": None, "n": 0}
    mae = sum(abs(e) for e in errors) / len(errors)
    rmse = (sum(e ** 2 for e in errors) / len(errors)) ** 0.5
    bias = sum(errors) / len(errors)
    return {"status": "ok", "mae": round(mae, 2), "rmse": round(rmse, 2),
            "bias": round(bias, 2), "n": len(errors)}
