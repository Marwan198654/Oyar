# -*- coding: utf-8 -*-
"""
core/codes.py
==============
جدول الربط الرسمي بين أسماء الظواهر الجوية بالعربية وأكواد WMO/ICAO
المستخدمة في METAR (WW - present weather) و SYNOP (ww / W1W2).

المصدر:
- ICAO Annex 3 / METAR present-weather significant weather codes.
- WMO-No. 306, Manual on Codes, Code table 4677 (ww) و 4561 (W1W2 - past weather).

هذا الجدول "قابل للتحديث" (بند 30) -- عند صدور نسخة رسمية جديدة يكفي تعديل
هذا الملف فقط دون المساس بمنطق التوليد في metar.py / synop.py.

كل ظاهرة تحمل:
- category: الفئة (هطول / عواصف / رؤية / غبار ورمال / أخرى)
- metar_code: رمز METAR (قد يكون None إذا لم يكن للظاهرة رمز مباشر)
- synop_ww: رمز SYNOP الحالي (ww, جدول 4677) إن وجد
- synop_w1w2: رمز SYNOP الطقس السابق (جدول 4561) إن وجد
"""

PHENOMENA_TABLE = {
    # -------- الهطول --------
    "rain": {
        "label_ar": "مطر", "category": "precipitation",
        "metar_code": "RA", "synop_ww": "61", "synop_w1w2": "6",
    },
    "drizzle": {
        "label_ar": "رذاذ", "category": "precipitation",
        "metar_code": "DZ", "synop_ww": "51", "synop_w1w2": "5",
    },
    "rain_showers": {
        "label_ar": "زخات مطر", "category": "precipitation",
        "metar_code": "SHRA", "synop_ww": "80", "synop_w1w2": "8",
    },
    "snow": {
        "label_ar": "ثلج", "category": "precipitation",
        "metar_code": "SN", "synop_ww": "71", "synop_w1w2": "7",
    },
    "snow_showers": {
        "label_ar": "زخات ثلج", "category": "precipitation",
        "metar_code": "SHSN", "synop_ww": "85", "synop_w1w2": "7",
    },
    "hail": {
        "label_ar": "برد", "category": "precipitation",
        "metar_code": "GR", "synop_ww": "89", "synop_w1w2": "9",
    },
    "ice_pellets": {
        "label_ar": "حبيبات جليدية", "category": "precipitation",
        "metar_code": "PL", "synop_ww": "79", "synop_w1w2": "7",
    },
    # -------- العواصف --------
    "thunderstorm": {
        "label_ar": "عاصفة رعدية", "category": "storm",
        "metar_code": "TS", "synop_ww": "95", "synop_w1w2": "9",
    },
    "lightning": {
        "label_ar": "برق", "category": "storm",
        "metar_code": None, "synop_ww": "17", "synop_w1w2": None,
    },
    # -------- الرؤية --------
    "fog": {
        "label_ar": "ضباب", "category": "visibility",
        "metar_code": "FG", "synop_ww": "45", "synop_w1w2": "4",
    },
    "mist": {
        "label_ar": "ضباب خفيف", "category": "visibility",
        "metar_code": "BR", "synop_ww": "10", "synop_w1w2": None,
    },
    "haze": {
        "label_ar": "شبورة / ضباب دخاني", "category": "visibility",
        "metar_code": "HZ", "synop_ww": "05", "synop_w1w2": None,
    },
    # -------- الغبار والرمال --------
    "dust": {
        "label_ar": "غبار", "category": "dust_sand",
        "metar_code": "DU", "synop_ww": "06", "synop_w1w2": None,
    },
    "dust_suspended": {
        "label_ar": "غبار عالق", "category": "dust_sand",
        "metar_code": "DU", "synop_ww": "06", "synop_w1w2": None,
    },
    "duststorm": {
        "label_ar": "عاصفة ترابية", "category": "dust_sand",
        "metar_code": "DS", "synop_ww": "09", "synop_w1w2": "9",
    },
    "sandstorm": {
        "label_ar": "عاصفة رملية", "category": "dust_sand",
        "metar_code": "SS", "synop_ww": "09", "synop_w1w2": "9",
    },
    "dust_whirls": {
        "label_ar": "دوامات غبارية", "category": "dust_sand",
        "metar_code": "PO", "synop_ww": "08", "synop_w1w2": None,
    },
    # -------- ظواهر أخرى --------
    "frost": {
        "label_ar": "صقيع", "category": "other",
        "metar_code": None, "synop_ww": "24", "synop_w1w2": None,
    },
    "dew": {
        "label_ar": "ندى", "category": "other",
        "metar_code": None, "synop_ww": None, "synop_w1w2": None,
    },
    "other": {
        "label_ar": "ظواهر أخرى", "category": "other",
        "metar_code": None, "synop_ww": None, "synop_w1w2": None,
    },
}

CATEGORIES_AR = {
    "precipitation": "الهطول",
    "storm": "العواصف",
    "visibility": "الرؤية",
    "dust_sand": "الغبار والرمال",
    "other": "ظواهر أخرى",
}

INTENSITY_PREFIX = {
    "light": "-",
    "moderate": "",
    "heavy": "+",
}


def get_phenomenon(key: str) -> dict:
    if key not in PHENOMENA_TABLE:
        raise KeyError(f"ظاهرة غير معرّفة في جدول الأكواد الرسمي: {key}")
    return PHENOMENA_TABLE[key]


# -------- كتل السحب (Cloud genera) لـ SYNOP CL/CM/CH (جدول 0513/0515/0509 مبسّط) --------
CLOUD_TYPES_LOW = ["Cu", "Sc", "St", "Cb", "لا يوجد"]
CLOUD_TYPES_MID = ["As", "Ac", "Ns", "لا يوجد"]
CLOUD_TYPES_HIGH = ["Ci", "Cc", "Cs", "لا يوجد"]
