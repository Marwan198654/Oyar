# -*- coding: utf-8 -*-
"""
core/backup.py
================
النسخ الاحتياطي والاستعادة لقاعدة بيانات المحطة (بند #28).
"""

from __future__ import annotations
import os
import shutil
import sqlite3
from datetime import datetime
from core.database import DB_PATH

BACKUP_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "backups")


def create_backup() -> str:
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if not os.path.exists(DB_PATH):
        raise FileNotFoundError("قاعدة البيانات غير موجودة بعد -- لم يتم إدخال أي بيانات")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(BACKUP_DIR, f"oyar_backup_{timestamp}.db")

    # استخدام واجهة SQLite backup API لضمان نسخة متّسقة حتى أثناء الكتابة
    src = sqlite3.connect(DB_PATH)
    dst = sqlite3.connect(backup_path)
    with dst:
        src.backup(dst)
    src.close()
    dst.close()
    return backup_path


def list_backups() -> list:
    if not os.path.isdir(BACKUP_DIR):
        return []
    files = [f for f in os.listdir(BACKUP_DIR) if f.endswith(".db")]
    files.sort(reverse=True)
    return [os.path.join(BACKUP_DIR, f) for f in files]


def restore_backup(backup_path: str) -> str:
    """يستعيد قاعدة بيانات من نسخة احتياطية، مع أخذ نسخة أمان من الحالية أولاً."""
    if not os.path.exists(backup_path):
        raise FileNotFoundError(f"ملف النسخة الاحتياطية غير موجود: {backup_path}")

    if os.path.exists(DB_PATH):
        safety_copy = DB_PATH + f".before_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(DB_PATH, safety_copy)

    shutil.copy2(backup_path, DB_PATH)
    return DB_PATH
