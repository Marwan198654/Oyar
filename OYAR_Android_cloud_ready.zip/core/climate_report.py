# -*- coding: utf-8 -*-
"""
core/climate_report.py
========================
توليد التقرير المناخي اليومي لمحطة عمران OYAR من رصدات يوم كامل
(00:00 - 23:59 UTC). بند #22.
"""

from __future__ import annotations
from datetime import datetime, timezone
from core.database import STATION_INFO, get_day_observations, search_observations, decode_phenomena
from core.calculations import compute_qnh


def _avg(values):
    vals = [v for v in values if v is not None]
    return round(sum(vals) / len(vals), 1) if vals else None


def _max_with_time(rows, field, time_field="obs_time_utc"):
    best = None
    for r in rows:
        v = r.get(field)
        if v is not None and (best is None or v > best[0]):
            best = (v, r.get(time_field))
    return best or (None, None)


def _min_with_time(rows, field, time_field="obs_time_utc"):
    best = None
    for r in rows:
        v = r.get(field)
        if v is not None and (best is None or v < best[0]):
            best = (v, r.get(time_field))
    return best or (None, None)


def _dominant_wind_dir(rows):
    dirs = [r["wind_dir_deg"] for r in rows if r.get("wind_dir_deg") is not None]
    if not dirs:
        return None
    buckets = {}
    for d in dirs:
        sector = round(d / 10.0) * 10 % 360
        buckets[sector] = buckets.get(sector, 0) + 1
    return max(buckets, key=buckets.get)


def build_daily_climate_report(report_date: str) -> dict:
    rows = get_day_observations(report_date)
    if not rows:
        return {"report_date": report_date, "status": "لا توجد رصدات لهذا اليوم", "rows_count": 0}

    temps = [r["temp_dry_c"] for r in rows if r.get("temp_dry_c") is not None]
    rh_vals = [r["rh_pct"] for r in rows if r.get("rh_pct") is not None]
    pressures = [r["pressure_station_hpa"] for r in rows if r.get("pressure_station_hpa") is not None]

    tmax, tmax_time = _max_with_time(rows, "temp_dry_c")
    tmin, tmin_time = _min_with_time(rows, "temp_dry_c")
    wmax, wmax_time = _max_with_time(rows, "wind_speed_kt")

    visible_rows = [r for r in rows if r.get("visibility_km") is not None]
    min_vis = min((r["visibility_km"] for r in visible_rows), default=None)

    rainfall_total = round(sum(r.get("rainfall_mm") or 0 for r in rows), 1)

    cloud_vals = [r["cloud_total_octas"] for r in rows if r.get("cloud_total_octas") is not None]

    wind_run_first = rows[0].get("wind_run_counter")
    wind_run_last = rows[-1].get("wind_run_counter")
    wind_run_diff = None
    try:
        if wind_run_first is not None and wind_run_last is not None:
            wind_run_diff = int(wind_run_last) - int(wind_run_first)
    except (ValueError, TypeError):
        wind_run_diff = None

    def soil_stats(field):
        vals = [r[field] for r in rows if r.get(field) is not None]
        if not vals:
            return {"avg": None, "max": None, "min": None}
        return {"avg": round(sum(vals) / len(vals), 1), "max": max(vals), "min": min(vals)}

    phenomena_seen = []
    for row in rows:
        for ph in decode_phenomena(row):
            key = ph.get("key") if isinstance(ph, dict) else None
            if key and key not in phenomena_seen:
                phenomena_seen.append(key)

    # أسماء عربية للعرض، مع الاحتفاظ بالمفتاح البرمجي للتدقيق.
    from core.codes import get_phenomenon
    phenomena_ar = []
    for key in phenomena_seen:
        try:
            phenomena_ar.append(get_phenomenon(key)["label_ar"])
        except KeyError:
            phenomena_ar.append(key)

    report = {
        "station": STATION_INFO,
        "report_date": report_date,
        "period": "00:00 - 23:59 UTC",
        "rows_count": len(rows),
        "temperature": {
            "avg_c": _avg(temps),
            "max_c": tmax, "max_time_utc": tmax_time,
            "min_c": tmin, "min_time_utc": tmin_time,
        },
        "humidity": {
            "avg_pct": _avg(rh_vals),
            "max_pct": max(rh_vals) if rh_vals else None,
            "min_pct": min(rh_vals) if rh_vals else None,
        },
        "pressure": {
            "avg_hpa": _avg(pressures),
            "max_hpa": max(pressures) if pressures else None,
            "min_hpa": min(pressures) if pressures else None,
        },
        "wind": {
            "max_speed_kt": wmax, "max_speed_time_utc": wmax_time,
            "dominant_direction_deg": _dominant_wind_dir(rows),
            "run_counter_start": wind_run_first,
            "run_counter_end": wind_run_last,
            "run_counter_diff": wind_run_diff,
        },
        "visibility": {"min_km": min_vis},
        "clouds": {
            "avg_total_octas": _avg(cloud_vals),
            "max_total_octas": max(cloud_vals) if cloud_vals else None,
        },
        "rainfall": {"total_mm": rainfall_total},
        "phenomena": {"keys": phenomena_seen, "labels_ar": phenomena_ar},
        "soil": {
            "5cm": soil_stats("soil_temp_5cm"),
            "10cm": soil_stats("soil_temp_10cm"),
            "20cm": soil_stats("soil_temp_20cm"),
        },
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "مكتمل" if len(rows) >= 8 else "بيانات جزئية (أقل من 8 رصدات في اليوم)",
    }
    return report


def render_daily_report_text(report: dict) -> str:
    if report.get("rows_count", 0) == 0:
        return f"لا توجد بيانات كافية لإصدار التقرير المناخي بتاريخ {report['report_date']}"

    s = report["station"]
    t = report["temperature"]; h = report["humidity"]; p = report["pressure"]
    w = report["wind"]; v = report["visibility"]; c = report["clouds"]
    r = report["rainfall"]; soil = report["soil"]

    lines = [
        f"التقرير المناخي اليومي - محطة {s['name_ar']} ({s['name_code']})",
        f"رقم المحطة WMO: {s['wmo_id']} | {s['lat']}°N {s['lon']}°E | الارتفاع: {s['elevation_m']} m",
        f"التاريخ: {report['report_date']}  | الفترة: {report['period']}",
        f"عدد الرصدات المستخدمة: {report['rows_count']}  | الحالة: {report['status']}",
        "",
        "-- درجات الحرارة --",
        f"المتوسط: {t['avg_c']} °C | العظمى: {t['max_c']} °C ({t['max_time_utc']}) | الصغرى: {t['min_c']} °C ({t['min_time_utc']})",
        "-- الرطوبة --",
        f"المتوسط: {h['avg_pct']}% | الأعلى: {h['max_pct']}% | الأدنى: {h['min_pct']}%",
        "-- الضغط (المحطة) --",
        f"المتوسط: {p['avg_hpa']} hPa | الأعلى: {p['max_hpa']} hPa | الأدنى: {p['min_hpa']} hPa",
        "-- الرياح --",
        f"أعلى سرعة: {w['max_speed_kt']} kt ({w['max_speed_time_utc']}) | الاتجاه السائد: {w['dominant_direction_deg']}°",
        f"جريان الرياح: {w['run_counter_start']} → {w['run_counter_end']} (الفرق: {w['run_counter_diff']})",
        "-- الرؤية والسحب --",
        f"أقل رؤية: {v['min_km']} km | متوسط السحب الكلية: {c['avg_total_octas']} Octas | أقصى كمية: {c['max_total_octas']} Octas",
        "-- الأمطار --",
        f"المجموع اليومي: {r['total_mm']} mm",
        "-- الظواهر الجوية المرصودة --",
        f"{', '.join(report['phenomena']['labels_ar']) if report['phenomena']['labels_ar'] else 'لا توجد ظواهر مسجلة'}",
        "-- حرارة التربة --",
        f"5cm: متوسط {soil['5cm']['avg']} / عظمى {soil['5cm']['max']} / صغرى {soil['5cm']['min']}",
        f"10cm: متوسط {soil['10cm']['avg']} / عظمى {soil['10cm']['max']} / صغرى {soil['10cm']['min']}",
        f"20cm: متوسط {soil['20cm']['avg']} / عظمى {soil['20cm']['max']} / صغرى {soil['20cm']['min']}",
        "",
        f"وقت إنشاء التقرير (UTC): {report['generated_at_utc']}",
    ]
    return "\n".join(lines)
