# -*- coding: utf-8 -*-
"""
core/metar.py
==============
مولّد تقارير METAR وفق هيكل ICAO Annex 3 / WMO-No. 306 القياسي.

يبني السلسلة من بيانات سجل رصد واحد. لا يُستخدم CAVOK أو NSC إلا عند
تحقق شروطهما الرسمية بدقة (بند 18):
  - CAVOK: رؤية >= 10km، لا سحب أقل من 5000ft (أو دون الحد الأدنى للـ MVA)
    ولا Cb/TCU، ولا ظواهر جوية ذات دلالة.
  - NSC (No Significant Cloud): تُستخدم فقط عند عدم رصد سحب ذات دلالة
    وليست هناك حالة CAVOK كاملة (رؤية أو طقس لا يحقق CAVOK).
"""

from __future__ import annotations
from core.calculations import compute_qnh
from core.database import STATION_INFO
from core.codes import get_phenomenon, INTENSITY_PREFIX


def _wind_group(wind_dir, wind_speed_kt, gust_kt=None):
    if wind_dir is None or wind_speed_kt is None:
        return "/////KT"
    d = "VRB" if wind_dir is None else f"{int(wind_dir):03d}"
    s = f"{int(round(wind_speed_kt)):02d}"
    g = f"G{int(round(gust_kt)):02d}" if gust_kt else ""
    return f"{d}{s}{g}KT"


def _visibility_group(vis_km):
    if vis_km is None:
        return "////"
    meters = vis_km * 1000
    if meters >= 10000:
        return "9999"
    return f"{int(round(meters / 100.0) * 100):04d}"


def _cloud_group(octas, base_ft, cloud_type=None):
    """يحوّل مستوى سحابي واحد إلى مجموعة METAR (FEWxxx/SCTxxx/BKNxxx/OVCxxx)."""
    if octas is None or octas == 0:
        return None
    if octas <= 2:
        cover = "FEW"
    elif octas <= 4:
        cover = "SCT"
    elif octas <= 7:
        cover = "BKN"
    else:
        cover = "OVC"
    if base_ft is None:
        return None
    height_code = f"{int(round(base_ft / 100.0)):03d}"
    suffix = "CB" if cloud_type == "Cb" else ""
    return f"{cover}{height_code}{suffix}"


def _is_cavok(vis_km, phenomena, cloud_levels):
    if vis_km is None or vis_km < 10:
        return False
    if phenomena:
        return False
    for lvl in cloud_levels:
        octas, base_ft, ctype = lvl
        if octas and octas > 0:
            if base_ft is not None and base_ft < 5000:
                return False
            if ctype == "Cb":
                return False
    return True


def _present_weather_group(phenomena: list):
    """phenomena: قائمة dict فيها key الظاهرة و intensity."""
    groups = []
    for ph in phenomena:
        info = get_phenomenon(ph["key"])
        if not info.get("metar_code"):
            continue
        prefix = INTENSITY_PREFIX.get(ph.get("intensity", "moderate"), "")
        groups.append(f"{prefix}{info['metar_code']}")
    return " ".join(groups)


def build_metar(obs: dict) -> dict:
    """
    obs: سجل الرصد (dict) كما يُخزَّن في قاعدة البيانات + phenomena قائمة بايثون.
    يعيد dict فيه النص النهائي وتفاصيل كل مجموعة (للتدقيق/الاختبار).
    """
    station = f"OY{STATION_INFO['wmo_id'][-3:]}" if False else "OYAR"  # معرف ICAO للمحطة
    day = obs["obs_date"][-2:]
    time_hhmm = obs["obs_time_utc"].replace(":", "")
    time_group = f"{day}{time_hhmm}Z"

    wind = _wind_group(obs.get("wind_dir_deg"), obs.get("wind_speed_kt"))

    phenomena = obs.get("phenomena", []) or []
    cloud_levels = [
        (obs.get("cloud_low_octas"), obs.get("cloud_low_base_ft"), obs.get("cloud_low_type")),
        (obs.get("cloud_mid_octas"), obs.get("cloud_mid_base_ft"), obs.get("cloud_mid_type")),
        (obs.get("cloud_high_octas"), obs.get("cloud_high_base_ft"), obs.get("cloud_high_type")),
    ]

    cavok = _is_cavok(obs.get("visibility_km"), phenomena, cloud_levels)

    if cavok:
        vis_and_cloud = "CAVOK"
    else:
        vis_group = _visibility_group(obs.get("visibility_km"))
        cloud_groups = [g for g in (_cloud_group(*lvl) for lvl in cloud_levels) if g]
        if not cloud_groups and obs.get("cloud_total_octas") == 0:
            cloud_groups = ["NSC"]
        vis_and_cloud = " ".join([vis_group] + cloud_groups) if cloud_groups else vis_group

    weather = _present_weather_group(phenomena) if not cavok else ""

    t = obs.get("temp_dry_c")
    td = obs.get("dew_point_c")
    def _t_fmt(v):
        if v is None:
            return "//"
        sign = "M" if v < 0 else ""
        return f"{sign}{abs(int(round(v))):02d}"
    temp_group = f"{_t_fmt(t)}/{_t_fmt(td)}"

    qnh = None
    if obs.get("pressure_station_hpa") is not None:
        qnh = compute_qnh(obs["pressure_station_hpa"], STATION_INFO["elevation_m"], t or 15.0)
    qnh_group = qnh["metar_group"] if qnh else "Q////"

    parts = [station, time_group, wind, vis_and_cloud]
    if weather:
        parts.append(weather)
    parts += [temp_group, qnh_group]

    text = "METAR " + " ".join(p for p in parts if p) + "="

    return {
        "text": text,
        "station": station,
        "time_group": time_group,
        "wind": wind,
        "visibility_cloud": vis_and_cloud,
        "weather": weather,
        "temperature": temp_group,
        "qnh": qnh_group,
        "qnh_detail": qnh,
        "cavok_applied": cavok,
    }
