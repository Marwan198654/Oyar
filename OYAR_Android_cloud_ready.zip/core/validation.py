# -*- coding: utf-8 -*-
"""
core/validation.py
====================
التحقق من صحة بيانات الرصد قبل الحفظ أو إصدار أي تقرير (بند #25).
لا يخترع النظام أي بيانات مفقودة -- الحقول الفارغة تبقى None وتُعرض
كـ "غير متاح / بيانات مفقودة" في التقارير.
"""

from __future__ import annotations
import re
from datetime import datetime

WIND_RUN_RE = re.compile(r"^\d{5}$")


class ValidationError(Exception):
    def __init__(self, errors: list):
        self.errors = errors
        super().__init__("؛ ".join(errors))


def validate_observation(data: dict) -> list:
    """يعيد قائمة رسائل الخطأ (فارغة = صحيح)."""
    errors = []

    # التاريخ والوقت
    try:
        datetime.strptime(data.get("obs_date", ""), "%Y-%m-%d")
    except ValueError:
        errors.append("تاريخ الرصد غير صحيح (الصيغة المطلوبة YYYY-MM-DD)")

    try:
        datetime.strptime(data.get("obs_time_utc", ""), "%H:%M")
    except ValueError:
        errors.append("وقت الرصد غير صحيح (نظام 24 ساعة HH:MM)")

    # الرياح
    wd = data.get("wind_dir_deg")
    if wd is not None and not (0 <= wd <= 360):
        errors.append("اتجاه الرياح يجب أن يكون بين 000 و 360 درجة")

    ws = data.get("wind_speed_kt")
    if ws is not None and ws < 0:
        errors.append("سرعة الرياح لا يمكن أن تكون سالبة")

    wr = data.get("wind_run_counter")
    if wr is not None and wr != "" and not WIND_RUN_RE.match(str(wr)):
        errors.append("جريان الرياح يجب أن يكون 5 أرقام بالضبط (00000-99999)")

    # الرؤية
    vis = data.get("visibility_km")
    if vis is not None and vis < 0:
        errors.append("الرؤية لا يمكن أن تكون سالبة")

    # الضغط
    p = data.get("pressure_station_hpa")
    if p is not None and not (500 <= p <= 1100):
        errors.append("قراءة الضغط خارج المدى الفيزيائي المعقول (500-1100 hPa)")

    # الحرارة
    dry = data.get("temp_dry_c")
    wet = data.get("temp_wet_c")
    if dry is not None and not (-60 <= dry <= 60):
        errors.append("درجة الحرارة الجافة خارج المدى المعقول")
    if wet is not None and dry is not None and wet > dry + 0.01:
        errors.append("درجة الحرارة المبللة لا يمكن أن تكون أعلى من الجافة")

    # السحب
    for level in ["cloud_total_octas", "cloud_low_octas", "cloud_mid_octas", "cloud_high_octas"]:
        v = data.get(level)
        if v is not None and not (0 <= v <= 8):
            errors.append(f"كمية السحب ({level}) يجب أن تكون بين 0 و 8")

    # الأمطار
    rain = data.get("rainfall_mm")
    if rain is not None and rain < 0:
        errors.append("كمية الأمطار لا يمكن أن تكون سالبة")

    # حرارة التربة
    for f in ["soil_temp_5cm", "soil_temp_10cm", "soil_temp_20cm"]:
        v = data.get(f)
        if v is not None and not (-30 <= v <= 70):
            errors.append(f"قراءة حرارة التربة ({f}) خارج المدى المعقول")

    return errors


def apply_cloud_absence_rule(data: dict) -> dict:
    """
    بند #13: إذا كانت كمية السحب لمستوى ما = 0، يُضبط النوع/الارتفاع/الاتجاه
    تلقائياً. لا تُستخدم 0 للدلالة على بيانات مفقودة أبداً (تبقى None).
    """
    data = dict(data)
    for level, type_f, base_f, dir_f in [
        ("cloud_low_octas", "cloud_low_type", "cloud_low_base_ft", "cloud_low_dir_deg"),
        ("cloud_mid_octas", "cloud_mid_type", "cloud_mid_base_ft", "cloud_mid_dir_deg"),
        ("cloud_high_octas", "cloud_high_type", "cloud_high_base_ft", "cloud_high_dir_deg"),
    ]:
        if data.get(level) == 0:
            data[type_f] = "لا يوجد"
            data[base_f] = None
            data[dir_f] = None
    return data

# تحقق إضافي لحقول FM-12 SYNOP الاختيارية/الموسعة.
def validate_synop_fields(data: dict) -> list:
    errors = []
    for field, allowed in {
        "synop_iw": {"0", "1", "3", "4", "/"},
        "synop_ir": {"0", "1", "2", "3", "4"},
        "synop_ix": {"1", "2", "3", "4", "5"},
    }.items():
        v = data.get(field)
        if v is not None and str(v) not in allowed:
            errors.append(f"{field} يحتوي قيمة SYNOP غير صالحة")
    for field in ("synop_visibility_code",):
        v = data.get(field)
        if v is not None:
            sv = str(v)
            if len(sv) != 2 or not sv.isdigit():
                errors.append(f"{field} يجب أن يكون رقمين")
            elif sv in {"51", "52", "53", "54", "55"}:
                errors.append(f"{field} يستخدم رمزاً غير مستخدم في Table 4377")
    v = data.get("synop_h_code")
    if v is not None and (len(str(v)) != 1 or not str(v).isdigit()):
        errors.append("synop_h_code يجب أن يكون رقماً واحداً")
    v = data.get("pressure_tendency_characteristic")
    if v is not None and str(v) not in set("012345678"):
        errors.append("رمز اتجاه الضغط يجب أن يكون 0..8")
    for field in ("pressure_msl_hpa", "pressure_change_3h_hpa", "rainfall_24h_mm"):
        v = data.get(field)
        if v is not None and v < 0:
            errors.append(f"{field} لا يمكن أن يكون سالباً")
    return errors
