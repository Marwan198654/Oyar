# -*- coding: utf-8 -*-
"""
core/export_excel.py
======================
تصدير السجلات إلى Excel بأسماء أعمدة عربية واضحة مع الوحدات (بند #27).
"""

from __future__ import annotations
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill

COLUMN_MAP = [
    ("obs_date", "التاريخ"),
    ("obs_time_utc", "الوقت (UTC)"),
    ("wind_dir_deg", "اتجاه الرياح (°)"),
    ("wind_speed_kt", "سرعة الرياح (kt)"),
    ("wind_run_counter", "جريان الرياح (عداد)"),
    ("visibility_km", "الرؤية (km)"),
    ("weather_state", "حالة الطقس"),
    ("pressure_station_hpa", "الضغط الجوي (hPa)"),
    ("temp_dry_c", "الحرارة الجافة (°C)"),
    ("temp_wet_c", "الحرارة المبللة (°C)"),
    ("dew_point_c", "نقطة الندى (°C)"),
    ("rh_pct", "الرطوبة النسبية (%)"),
    ("vapor_pressure_hpa", "ضغط بخار الماء (hPa)"),
    ("tmax_c", "العظمى (°C)"),
    ("tmin_c", "الصغرى (°C)"),
    ("soil_temp_5cm", "حرارة التربة 5 سم (°C)"),
    ("soil_temp_10cm", "حرارة التربة 10 سم (°C)"),
    ("soil_temp_20cm", "حرارة التربة 20 سم (°C)"),
    ("cloud_total_octas", "السحب الكلية (Octas)"),
    ("cloud_low_octas", "السحب المنخفضة (Octas)"),
    ("cloud_low_base_ft", "ارتفاع قاعدة السحب المنخفضة (ft)"),
    ("cloud_mid_octas", "السحب المتوسطة (Octas)"),
    ("cloud_mid_base_ft", "ارتفاع قاعدة السحب المتوسطة (ft)"),
    ("cloud_high_octas", "السحب العالية (Octas)"),
    ("cloud_high_base_ft", "ارتفاع قاعدة السحب العالية (ft)"),
    ("rainfall_mm", "الأمطار (mm)"),
    ("qnh_hpa", "QNH (hPa)"),
]


def export_observations_to_excel(rows: list, filepath: str):
    wb = Workbook()
    ws = wb.active
    ws.title = "سجلات الرصد"
    ws.sheet_view.rightToLeft = True

    header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True)

    for col_idx, (_, label) in enumerate(COLUMN_MAP, start=1):
        cell = ws.cell(row=1, column=col_idx, value=label)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    for row_idx, rec in enumerate(rows, start=2):
        for col_idx, (key, _) in enumerate(COLUMN_MAP, start=1):
            ws.cell(row=row_idx, column=col_idx, value=rec.get(key, ""))

    for col_idx in range(1, len(COLUMN_MAP) + 1):
        ws.column_dimensions[chr(64 + col_idx) if col_idx <= 26 else "A"].width = 20

    wb.save(filepath)
    return filepath
