# -*- coding: utf-8 -*-
"""مولّد FM-12 SYNOP لمحطة أرضية ثابتة.

يدعم المجموعات الدولية الأساسية في Section 0/1، والجموعات الشائعة في Section 3.
الترميز مبني على WMO-No. 306؛ وعند عدم توفر مدخل صريح لا يخمّن النظام قيمة
كودية حساسة، بل يحذف المجموعة الاختيارية أو يستخدم /// حيث يسمح نموذج الكود.
"""
from __future__ import annotations
from datetime import datetime, timedelta
from core.database import STATION_INFO


def _sign_digit(value):
    return "1" if value is not None and value < 0 else "0"


def _temp_group(prefix, value):
    if value is None:
        return None
    return f"{prefix}{_sign_digit(value)}{int(round(abs(value) * 10)):03d}"


def _pressure_group(prefix, pressure_hpa):
    if pressure_hpa is None:
        return None
    if not 500 <= pressure_hpa <= 1100:
        raise ValueError(f"ضغط SYNOP خارج المدى: {pressure_hpa}")
    return f"{prefix}{int(round(pressure_hpa * 10)) % 10000:04d}"


def _visibility_code_from_km(visibility_km):
    """ترميز VV وفق WMO code table 4377، مع التقريب إلى الأسفل."""
    if visibility_km is None:
        return None
    v = float(visibility_km)
    if v < 0:
        raise ValueError("الرؤية لا يمكن أن تكون سالبة")
    # 00..50: قراءة مباشرة كل 0.1 km، والقيمة الأقل من 0.1 km هي 00.
    if v < 5.0:
        code = int(v * 10)
        return f"{max(0, min(code, 50)):02d}"
    if v < 5.0000001:
        return "50"
    # 56..80: 6..30 km
    if v < 6.0:
        return "50"
    if v <= 30.0:
        km = int(v)
        return f"{50 + km:02d}"
    # 81..89: 35,40,...,70 km. اختر أصغر حد لا يتجاوز الرؤية.
    thresholds = [(35, 81), (40, 82), (45, 83), (50, 84),
                  (55, 85), (60, 86), (65, 87), (70, 88)]
    code = 80
    for threshold, c in thresholds:
        if v >= threshold:
            code = c
        else:
            break
    if v >= 70:
        return "89"
    return f"{code:02d}"


def _visibility_code(obs):
    # يقبل الرمز الرسمي مباشرة، أو يحوله من visibility_km وفق Table 4377.
    code = obs.get("synop_visibility_code")
    if code is not None:
        code = str(code)
        if not (len(code) == 2 and code.isdigit()):
            raise ValueError("synop_visibility_code يجب أن يكون رقمين")
        if code in {"51", "52", "53", "54", "55"}:
            raise ValueError("رموز VV 51..55 غير مستخدمة في Table 4377")
        return code
    code = _visibility_code_from_km(obs.get("visibility_km"))
    return code or "//"


def _iR(obs):
    explicit = obs.get("synop_ir")
    if explicit is not None:
        if str(explicit) not in {"0", "1", "2", "3", "4"}:
            raise ValueError("iR يجب أن يكون 0..4")
        return str(explicit)
    return "1" if obs.get("rainfall_mm") is not None else "4"


def _ix(obs):
    explicit = obs.get("synop_ix")
    if explicit is not None:
        if str(explicit) not in {"1", "2", "3", "4", "5"}:
            raise ValueError("ix يجب أن يكون من قيم SYNOP المعتمدة 1..5")
        return str(explicit)
    # محطة مأهولة/رصد يدوي افتراضياً عندما تتوفر بيانات الطقس.
    return "1"


def _h_code(obs):
    code = obs.get("synop_h_code")
    if code is not None:
        code = str(code)
        if len(code) != 1 or not code.isdigit():
            raise ValueError("synop_h_code يجب أن يكون رقماً واحداً")
        return code
    return "/"


def _wind_group(N, wind_dir, wind_speed_kt):
    n = str(N) if N is not None else "/"
    if wind_dir is None:
        dd = "//"
    elif wind_speed_kt == 0:
        dd = "00"
    else:
        dd = f"{int(round(wind_dir / 10.0)) % 36:02d}"
    if wind_speed_kt is None:
        ff = "//"
    elif wind_speed_kt >= 99:
        ff = "99"
    else:
        ff = f"{int(round(wind_speed_kt)):02d}"
    return f"{n}{dd}{ff}"


def _wind_over_99_group(wind_speed_kt):
    if wind_speed_kt is None or wind_speed_kt < 99:
        return None
    # 00fff: السرعة الفعلية في وحدة iw، ثلاث خانات.
    return f"00{int(round(wind_speed_kt)):03d}"


def _cloud_low_medium_high(obs):
    nh = obs.get("cloud_low_octas")
    nh = str(nh) if nh is not None else "/"
    cl = _cloud_type_code(obs.get("cloud_low_type"), "low")
    cm = _cloud_type_code(obs.get("cloud_mid_type"), "mid")
    ch = _cloud_type_code(obs.get("cloud_high_type"), "high")
    return f"8{nh}{cl}{cm}{ch}"


_CLOUD_CODE_MAP = {
    "low": {"Cu": "1", "Sc": "4", "St": "6", "Cb": "9", "لا يوجد": "0"},
    "mid": {"As": "2", "Ac": "5", "Ns": "7", "لا يوجد": "0"},
    "high": {"Ci": "1", "Cc": "3", "Cs": "6", "لا يوجد": "0"},
}


def _cloud_type_code(cloud_type, level):
    if cloud_type is None:
        return "/"
    return _CLOUD_CODE_MAP.get(level, {}).get(cloud_type, "/")


def _weather_code_candidates(phenomena, field_name="synop_ww"):
    """إرجاع أكواد الطقس مرتبة وفق قواعد اختيار SYNOP.

    في ww: الرقم الأعلى هو الأهم عند تعدد الظواهر، مع الاستثناء الصريح
    للرمز 17 الذي يتقدم على 20..49. أما W1/W2 فيستخدمان نفس الفكرة
    مع جدول 4561: 9 ثم 8 ... ثم 3، مع تجاهل 0..2 باعتبارها غير مهمة.
    """
    from core.codes import get_phenomenon
    values = []
    for ph in phenomena or []:
        if not isinstance(ph, dict):
            continue
        key = ph.get("key") or ph.get("code")
        if not key:
            continue
        try:
            info = get_phenomenon(key)
        except KeyError:
            continue
        code = info.get(field_name)
        if code is None:
            continue
        try:
            code = int(str(code))
        except (TypeError, ValueError):
            continue
        values.append((code, key))
    return values


def _present_weather_priority(code):
    """مفتاح ترتيب Table 4677: 17 له أولوية خاصة على 20..49."""
    if code == 17:
        return 49_017
    return code


def _select_present_weather(phenomena):
    candidates = _weather_code_candidates(phenomena, "synop_ww")
    if not candidates:
        return None
    return str(max(candidates, key=lambda item: _present_weather_priority(item[0]))[0]).zfill(2)


def _select_past_weather(phenomena, present_code=None, explicit=None):
    """اختيار W1W2 وفق Table 4561.

    - 0..2 لا تعتبر ظواهر ذات أهمية.
    - W1 هو الأهم، وW2 ثاني الأهم.
    - إذا أمكن، لا نكرر ww في W1؛ وإذا كان نوع واحد فقط هو المتاح
      يتكرر في W1 وW2.
    - يمكن تمرير weather_past_code/سلسلة ``past_phenomena`` صراحة.
    """
    if explicit not in (None, "", "//"):
        value = str(explicit)
        if len(value) == 2 and all(ch.isdigit() for ch in value):
            if any(int(ch) > 2 for ch in value):
                return value
        raise ValueError("weather_past_code يجب أن يكون رقمين من 00..99، مع استخدام 00..02 فقط عند الحاجة")

    candidates = _weather_code_candidates(phenomena, "synop_w1w2")
    codes = [code for code, _ in candidates if code >= 3]
    # إزالة التكرارات مع الحفاظ على أعلى أهمية.
    codes = sorted(set(codes), reverse=True)
    if not codes:
        return None

    # إذا كانت ظاهرة الماضي الوحيدة هي نفس فئة ww، ابحث عن بديل مختلف
    # إن توفر؛ وإلا يسمح التكرار.
    if present_code is not None:
        p = int(str(present_code))
        different = [c for c in codes if c != p]
        if different:
            w1 = different[0]
            remaining = [c for c in codes if c != w1]
            w2 = remaining[0] if remaining else w1
            return f"{w1}{w2}"

    w1 = codes[0]
    w2 = codes[1] if len(codes) > 1 else w1
    return f"{w1}{w2}"


def _weather_group(phenomena, past_code=None, past_phenomena=None):
    """ترميز 7wwW1W2 لمحطة مأهولة وفق FM-12.

    إذا وُجدت عدة ظواهر حالية، يُختار أعلى ww وفق Table 4677، مع إعطاء
    الرمز 17 أولوية على 20..49. ويمكن تمرير ``past_phenomena`` كقائمة
    مستقلة لانتقاء W1/W2 من Table 4561.
    """
    ww = _select_present_weather(phenomena)
    past = _select_past_weather(
        past_phenomena if past_phenomena is not None else [],
        present_code=ww,
        explicit=past_code,
    )

    # إذا لم توجد ظاهرة حالية مهمة لكن توجد ظاهرة ماضية مهمة، نرسل // في ww.
    if ww is None and past is None:
        return None
    return f"7{ww or '//'}{past or '//'}"


def _rainfall_group(rainfall_mm, period_code="1"):
    if rainfall_mm is None:
        return None
    if str(period_code) not in {"1", "2", "3", "4", "5", "6", "7"}:
        raise ValueError("tR غير صالح")
    if rainfall_mm < 0:
        raise ValueError("كمية المطر لا يمكن أن تكون سالبة")
    if rainfall_mm == 0:
        rrr = "000"
    elif rainfall_mm < 1:
        rrr = "990"  # trace
    else:
        # RRR يمثل الكمية بالـ mm ضمن حدود 001..989 في الترميز التشغيلي المعتاد.
        rrr = f"{min(int(round(rainfall_mm)), 989):03d}"
    return f"6{rrr}{period_code}"


def _tendency_group(obs):
    a = obs.get("pressure_tendency_characteristic")
    change = obs.get("pressure_change_3h_hpa")
    if a is None or change is None:
        return None
    a = str(a)
    if a not in set("012345678"):
        raise ValueError("رمز اتجاه الضغط a يجب أن يكون 0..8")
    if change < 0:
        change = abs(change)
    return f"5{a}{min(int(round(change * 10)), 999):03d}"


def _section3(obs):
    groups = []
    # أقصى/أدنى الحرارة خلال الفترة المحددة محلياً.
    g = _temp_group("1", obs.get("tmax_c"))
    if g:
        groups.append(g)
    g = _temp_group("2", obs.get("tmin_c"))
    if g:
        groups.append(g)
    # أمطار 24 ساعة، عند إدخالها صراحة.
    if obs.get("rainfall_24h_mm") is not None:
        g = _rainfall_group(obs.get("rainfall_24h_mm"), obs.get("rainfall_24h_period_code", "7"))
        if g:
            groups.append(g)
    # مجموعات إقليمية/محلية لحرارة التربة، تبقى اختيارية.
    for depth, temp in (("1", obs.get("soil_temp_5cm")), ("2", obs.get("soil_temp_10cm")), ("3", obs.get("soil_temp_20cm"))):
        if temp is not None:
            groups.append(f"0{depth}{_sign_digit(temp)}{int(round(abs(temp) * 10)):03d}")
    return ["333"] + groups if groups else []


def _iw(obs):
    explicit = obs.get("synop_iw")
    if explicit is not None:
        explicit = str(explicit)
        if explicit not in {"0", "1", "3", "4", "/"}:
            raise ValueError("iw يجب أن يكون 0 أو 1 أو 3 أو 4 أو /")
        return explicit
    # المشروع يخزن السرعة بالعقدة، والواجهة تستخدم مقياس رياح؛ 4 = مقاسة بالأنيمومتر.
    return "4"


def build_synop(obs: dict) -> dict:
    """يبني رسالة SYNOP FM-12 موسعة من سجل رصد واحد."""
    dt = datetime.strptime(f"{obs['obs_date']} {obs['obs_time_utc']}", "%Y-%m-%d %H:%M")
    # GG في SYNOP هو أقرب ساعة كاملة UTC.
    if dt.minute >= 30:
        dt += timedelta(hours=1)
    day = dt.day
    hour = dt.hour
    iw = _iw(obs)
    header = f"AAXX {day:02d}{hour:02d}{iw}"
    station_id = STATION_INFO["wmo_id"]

    section1 = []
    section1.append(f"{_iR(obs)}{_ix(obs)}{_h_code(obs)}{_visibility_code(obs)}")
    section1.append(_wind_group(obs.get("cloud_total_octas"), obs.get("wind_dir_deg"), obs.get("wind_speed_kt")))
    high_wind = _wind_over_99_group(obs.get("wind_speed_kt"))
    if high_wind:
        section1.append(high_wind)

    for g in (
        _temp_group("1", obs.get("temp_dry_c")),
        _temp_group("2", obs.get("dew_point_c")),
        _pressure_group("3", obs.get("pressure_station_hpa")),
        _pressure_group("4", obs.get("pressure_msl_hpa")),
        _tendency_group(obs),
        _rainfall_group(obs.get("rainfall_mm"), obs.get("rainfall_period_code", "1")),
        _weather_group(obs.get("phenomena", []), obs.get("weather_past_code"), obs.get("past_phenomena", [])),
    ):
        if g:
            section1.append(g)

    # لا نضيف 8NhCLCMCH إلا عندما تكون بيانات السحب متاحة.
    if any(obs.get(k) is not None for k in ("cloud_total_octas", "cloud_low_octas", "cloud_mid_type", "cloud_high_type")):
        section1.append(_cloud_low_medium_high(obs))

    section3 = _section3(obs)
    full = f"{header} {station_id} " + " ".join(section1)
    if section3:
        full += " " + " ".join(section3)
    full += "="
    return {"text": full, "header": header, "station_id": station_id,
            "section1": section1, "section3": section3}
