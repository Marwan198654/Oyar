# -*- coding: utf-8 -*-
"""
core/export_pdf.py
====================
تصدير التقارير (مناخي / METAR / SYNOP) إلى PDF (بند #27).
يستخدم reportlab. النصوص العربية تُعرض كما هي (اتجاه الكتابة الكامل RTL
الكامل مع تشكيل الحروف يتطلب مكتبة arabic_reshaper + python-bidi على
جهاز الإنتاج؛ هنا يُترك دعمها اختيارياً عبر try/except حتى يعمل التصدير
حتى بدون تثبيت تلك الحزم).
"""

from __future__ import annotations
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas
from reportlab.lib import colors

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    _HAS_ARABIC_SUPPORT = True
except ImportError:
    _HAS_ARABIC_SUPPORT = False


def _shape(text: str) -> str:
    if _HAS_ARABIC_SUPPORT:
        reshaped = arabic_reshaper.reshape(text)
        return get_display(reshaped)
    return text


def export_text_report_to_pdf(title: str, body_lines: list, filepath: str):
    c = canvas.Canvas(filepath, pagesize=A4)
    width, height = A4
    margin = 2 * cm

    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(width / 2, height - margin, _shape(title))

    c.setFont("Helvetica", 10)
    y = height - margin - 1.2 * cm
    for line in body_lines:
        if y < margin:
            c.showPage()
            c.setFont("Helvetica", 10)
            y = height - margin
        c.drawRightString(width - margin, y, _shape(line))
        y -= 0.55 * cm

    c.save()
    return filepath


def export_table_to_pdf(title: str, headers: list, rows: list, filepath: str):
    c = canvas.Canvas(filepath, pagesize=A4)
    width, height = A4
    margin = 1.5 * cm

    c.setFont("Helvetica-Bold", 13)
    c.drawCentredString(width / 2, height - margin, _shape(title))

    col_width = (width - 2 * margin) / max(len(headers), 1)
    y = height - margin - 1 * cm

    c.setFont("Helvetica-Bold", 8)
    for i, h in enumerate(headers):
        x = width - margin - (i + 1) * col_width
        c.drawString(x, y, _shape(str(h)))
    y -= 0.5 * cm
    c.line(margin, y, width - margin, y)
    y -= 0.4 * cm

    c.setFont("Helvetica", 7.5)
    for row in rows:
        if y < margin:
            c.showPage()
            y = height - margin
            c.setFont("Helvetica", 7.5)
        for i, val in enumerate(row):
            x = width - margin - (i + 1) * col_width
            c.drawString(x, y, _shape(str(val)))
        y -= 0.45 * cm

    c.save()
    return filepath
