# -*- coding: utf-8 -*-
"""
core/logging_config.py
========================
تهيئة سجلات التشغيل (Logs) -- بند #32.
"""
import logging
import os
from logging.handlers import RotatingFileHandler

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")


def setup_logging():
    os.makedirs(LOG_DIR, exist_ok=True)
    log_path = os.path.join(LOG_DIR, "oyar_weather.log")

    root = logging.getLogger("oyar")
    root.setLevel(logging.INFO)

    if root.handlers:
        return root  # تجنب تكرار المعالجات عند إعادة الاستدعاء

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")

    file_handler = RotatingFileHandler(log_path, maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(fmt)
    root.addHandler(console_handler)

    return root
