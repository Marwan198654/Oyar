# -*- coding: utf-8 -*-
"""
core/calculations.py
=====================
وحدة الحسابات الجوية لمحطة عمران OYAR (WMO 41399).

مفصولة تماماً عن واجهة المستخدم وقاعدة البيانات (متطلب #31/#32).
كل دالة موثقة بمصدرها العلمي حتى يمكن مراجعتها والتأكد من صحتها.

المراجع:
- WMO-No. 8, Guide to Instruments and Methods of Observation (CIMO Guide)
  صيغة Magnus-Tetens لحساب نقطة الندى وضغط بخار الماء المشبع.
- ICAO Doc 7488 / Annex 3 لحساب QNH من ضغط المحطة (الصيغة الباروميترية القياسية).
- 1 hPa = 1 mb (تعريف رسمي، لا يحتاج تحويل عامل).
"""

from __future__ import annotations
import math
from dataclasses import dataclass

# ----------------------------------------------------------------------
# ثوابت فيزيائية / معيارية
# ----------------------------------------------------------------------
STATION_ELEVATION_M = 2239.0          # الارتفاع المرجعي الأصلي في قاعدة البيانات
STANDARD_TEMP_LAPSE = 0.0065          # K/m  (الجوي القياسي ICAO)
STANDARD_SEA_LEVEL_TEMP = 288.15      # K
STANDARD_SEA_LEVEL_PRESSURE = 1013.25 # hPa
GRAVITY = 9.80665
GAS_CONST_AIR = 287.05307             # J/(kg.K)

# معاملات Magnus-Tetens (WMO CIMO Guide, صيغة معتمدة للأرصاد التشغيلية)
MAGNUS_A = 6.1121   # hPa
MAGNUS_B = 17.502
MAGNUS_C = 240.97   # °C


# ----------------------------------------------------------------------
# تحويلات الوحدات
# ----------------------------------------------------------------------
def meters_to_feet(value_m: float) -> float:
    """تحويل متر -> قدم. 1 m = 3.28084 ft (تعريف قياسي)."""
    return round(value_m * 3.280839895, 1)


def feet_to_meters(value_ft: float) -> float:
    return round(value_ft / 3.280839895, 2)


def kt_to_ms(kt: float) -> float:
    """عقدة -> متر/ثانية. 1 kt = 0.514444 m/s (تعريف بحري دولي)."""
    return round(kt * 0.514444, 2)


def kt_to_kmh(kt: float) -> float:
    return round(kt * 1.852, 2)


def ms_to_kt(ms: float) -> float:
    return round(ms / 0.514444, 1)


def kmh_to_kt(kmh: float) -> float:
    return round(kmh / 1.852, 1)


STATION_ELEVATION_FT = meters_to_feet(STATION_ELEVATION_M)  # ~7346 ft


# ----------------------------------------------------------------------
# السيكرومترية: نقطة الندى / الرطوبة النسبية / ضغط بخار الماء
# ----------------------------------------------------------------------
def saturation_vapor_pressure(temp_c: float) -> float:
    """
    ضغط بخار الماء المشبّع عند درجة حرارة معينة (hPa).
    صيغة Magnus-Tetens: es = A * exp( B*T / (C+T) )
    """
    return MAGNUS_A * math.exp((MAGNUS_B * temp_c) / (MAGNUS_C + temp_c))


def psychrometric_constant(pressure_hpa: float) -> float:
    """
    الثابت السيكرومتري (hPa/°C) لمقياس حرارة مبلل مهوّى (Aspirated) قياسي.
    A = 6.62e-4 * P  (WMO CIMO Guide, Ch.4, للمكشوف المهوّى طبيعياً ~7.99e-4).
    نستخدم معامل المروحة/التهوية الطبيعية القياسي 6.66e-4 * P كافتراض تشغيلي
    شائع في المحطات السطحية اليدوية.
    """
    return 6.66e-4 * pressure_hpa


def compute_psychrometrics(dry_bulb_c: float, wet_bulb_c: float, pressure_hpa: float) -> dict:
    """
    يحسب: ضغط بخار الماء الفعلي، نقطة الندى، الرطوبة النسبية.
    يعيد dict بالنتائج + طريقة الحساب (للشفافية أمام المستخدم/المطور - بند 31).
    """
    if wet_bulb_c > dry_bulb_c + 0.01:
        raise ValueError("درجة الحرارة المبللة لا يمكن أن تكون أعلى من الجافة")

    es_wet = saturation_vapor_pressure(wet_bulb_c)
    gamma = psychrometric_constant(pressure_hpa)

    # معادلة السيكرومتر (Sprung/WMO): e = es(Tw) - gamma * (T - Tw) * P_factor
    e_actual = es_wet - gamma * (dry_bulb_c - wet_bulb_c) * 1.0
    e_actual = max(e_actual, 0.01)

    es_dry = saturation_vapor_pressure(dry_bulb_c)
    rh = (e_actual / es_dry) * 100.0
    rh = min(max(rh, 0.0), 100.0)

    # نقطة الندى بعكس صيغة Magnus من e_actual
    ln_term = math.log(e_actual / MAGNUS_A)
    dew_point = (MAGNUS_C * ln_term) / (MAGNUS_B - ln_term)

    return {
        "vapor_pressure_hpa": round(e_actual, 2),
        "dew_point_c": round(dew_point, 1),
        "relative_humidity_pct": round(rh, 1),
        "method": "Magnus-Tetens + Sprung psychrometric equation (WMO CIMO Guide Ch.4)",
    }


# ----------------------------------------------------------------------
# QNH
# ----------------------------------------------------------------------
def compute_qnh(station_pressure_hpa: float, elevation_m: float, temp_c: float) -> dict:
    """
    حساب QNH من ضغط المحطة (الصيغة الباروميترية القياسية المعتمدة من ICAO Doc 7488).

    القاعدة الرسمية: QNH هو ضغط المحطة بعد اختزاله إلى مستوى سطح البحر
    باستخدام الجو القياسي الدولي (ISA) فقط لعامل الاختزال (لا يستخدم درجة
    حرارة الهواء الفعلية في اختزال QNH وفق ICAO -- بخلاف QFF الذي يستخدم
    درجة الحرارة الفعلية). لذلك QNH يعتمد فقط على: ضغط المحطة + الارتفاع.

    الصيغة (ICAO Doc 7488 / Manual of Aeronautical Meteorological Practice):
        QNH = P_station * (1 - (0.0065 * H) / (T0 + 0.0065*H + 273.15)) ** (-5.2561)
    حيث T0 = 15°C (درجة حرارة الجو القياسي عند سطح البحر), H = ارتفاع المحطة.

    ملاحظة: تُستخدم الصيغة الأسية القياسية لـ ICAO. القيمة تُقرّب لأقرب hPa صحيح
    عند العرض بصيغة METAR (Qxxxx) لكن يُحتفظ بالقيمة الكاملة داخلياً.
    """
    H = elevation_m
    T0 = 15.0  # الجو القياسي عند سطح البحر (°C) -- ثابت، لا علاقة له بحرارة اليوم
    exponent = -5.2561
    factor = (1 - (STANDARD_TEMP_LAPSE * H) / (T0 + STANDARD_TEMP_LAPSE * H + 273.15)) ** exponent
    qnh = station_pressure_hpa * factor

    qnh_rounded = int(round(qnh))          # للعرض في METAR كصيغة Qxxxx (عدد صحيح)
    metar_group = f"Q{qnh_rounded:04d}"

    return {
        "station_pressure_hpa": round(station_pressure_hpa, 1),
        "qnh_hpa": round(qnh, 2),
        "qnh_rounded_hpa": qnh_rounded,
        "metar_group": metar_group,
        "method": "ICAO Doc 7488 barometric reduction (ISA, station elevation only)",
    }


# ----------------------------------------------------------------------
# اختبار سريع ذاتي عند التشغيل المباشر
# ----------------------------------------------------------------------
if __name__ == "__main__":
    r = compute_psychrometrics(25.0, 18.0, 800.0)
    print("Psychrometrics:", r)
    q = compute_qnh(800.0, STATION_ELEVATION_M, 25.0)
    print("QNH:", q)
    print("Elevation ft:", STATION_ELEVATION_FT)
