# -*- coding: utf-8 -*-
"""
core/scheduler.py
====================
خدمة الإصدار التلقائي للتقارير (بند #18/19/23/24).
- METAR كل ساعة، SYNOP كل 3 ساعات، التقرير المناخي اليومي عند 00:05 UTC
  من اليوم التالي.
- يعمل محلياً دون إنترنت (مؤقت Python فقط + قاعدة بيانات محلية).
- عند بدء التشغيل يفحص التقارير المتأخرة (التي فات موعدها ولم تُصدر)
  ويصدرها تلقائياً مع تسجيل الموعد المجدول ووقت الإصدار الفعلي وسبب التأخير.
"""

from __future__ import annotations
import threading
import time
import logging
from datetime import datetime, timedelta, timezone

from core.database import (
    STATION_INFO, get_latest_observation, report_exists, save_report,
    search_observations, decode_phenomena,
)
from core.metar import build_metar
from core.synop import build_synop, SYNOP_TIMES
from core.climate_report import build_daily_climate_report, render_daily_report_text

logger = logging.getLogger("oyar.scheduler")

LOCAL_UTC_OFFSET_HOURS = 3  # توقيت اليمن = UTC+3 (لعرض الوقت المحلي فقط)


def _local_time_str(dt_utc: datetime) -> str:
    local = dt_utc + timedelta(hours=LOCAL_UTC_OFFSET_HOURS)
    return local.strftime("%Y-%m-%d %H:%M") + " (محلي، اليمن)"


def _attach_phenomena(obs: dict) -> dict:
    """يضيف قائمة الظواهر (phenomena) للسجل -- محجوزة للتوسعة عند ربطها بجدول منفصل."""
    obs = dict(obs)
    obs["phenomena"] = decode_phenomena(obs)
    return obs


def generate_metar_for_latest(scheduled_at_utc=None, delay_reason=None):
    obs = get_latest_observation()
    if not obs:
        logger.warning("لا توجد رصدات لإصدار METAR")
        return None
    obs = _attach_phenomena(obs)
    result = build_metar(obs)
    now = datetime.now(timezone.utc)
    save_report(
        "METAR", obs["obs_date"], result["text"],
        period_start=obs["obs_time_utc"],
        scheduled_at_utc=scheduled_at_utc, delay_reason=delay_reason,
        issued_at_local=_local_time_str(now),
    )
    logger.info("تم إصدار METAR: %s", result["text"])
    return result


def generate_synop_for_latest(scheduled_at_utc=None, delay_reason=None):
    obs = get_latest_observation()
    if not obs:
        logger.warning("لا توجد رصدات لإصدار SYNOP")
        return None
    obs = _attach_phenomena(obs)
    result = build_synop(obs)
    now = datetime.now(timezone.utc)
    save_report(
        "SYNOP", obs["obs_date"], result["text"],
        period_start=obs["obs_time_utc"],
        scheduled_at_utc=scheduled_at_utc, delay_reason=delay_reason,
        issued_at_local=_local_time_str(now),
    )
    logger.info("تم إصدار SYNOP: %s", result["text"])
    return result


def generate_daily_report_for(date_str: str, scheduled_at_utc=None, delay_reason=None):
    if report_exists("DAILY_CLIMATE", date_str):
        logger.info("التقرير المناخي لتاريخ %s موجود مسبقاً -- تخطي (منع التكرار)", date_str)
        return None
    report = build_daily_climate_report(date_str)
    text = render_daily_report_text(report)
    now = datetime.now(timezone.utc)
    save_report(
        "DAILY_CLIMATE", date_str, text,
        period_start="00:00", period_end="23:59",
        scheduled_at_utc=scheduled_at_utc, delay_reason=delay_reason,
        issued_at_local=_local_time_str(now),
    )
    logger.info("تم إصدار التقرير المناخي اليومي لتاريخ %s", date_str)
    return report


def check_and_issue_missed_reports():
    """يُستدعى عند بدء تشغيل التطبيق: يفحص ما فات موعده ولم يُصدر بعد."""
    now = datetime.now(timezone.utc)
    yesterday = (now - timedelta(days=1)).strftime("%Y-%m-%d")

    # التقرير المناخي اليومي لأمس -- إن لم يصدر بعد 00:05 UTC
    if now.strftime("%H:%M") >= "00:05" or now.hour > 0:
        if not report_exists("DAILY_CLIMATE", yesterday):
            scheduled = f"{yesterday}T00:05:00+00:00"
            generate_daily_report_for(
                yesterday, scheduled_at_utc=scheduled,
                delay_reason="تم اكتشاف تقرير متأخر عند بدء تشغيل النظام (الجهاز كان مغلقاً في الموعد المجدول)",
            )


class ReportScheduler:
    """مجدول يعمل في خيط (thread) منفصل، يتحقق كل دقيقة من مواعيد الإصدار."""

    def __init__(self, check_interval_sec=60):
        self.check_interval_sec = check_interval_sec
        self._stop_event = threading.Event()
        self._thread = None
        self._last_metar_hour = None
        self._last_synop_hour = None
        self._last_daily_date = None

    def start(self):
        check_and_issue_missed_reports()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        logger.info("تم بدء المجدول التلقائي (Daily Scheduler)")

    def stop(self):
        self._stop_event.set()

    def _run(self):
        while not self._stop_event.is_set():
            try:
                self._tick()
            except Exception:
                logger.exception("خطأ في دورة المجدول")
            time.sleep(self.check_interval_sec)

    def _tick(self):
        now = datetime.now(timezone.utc)
        hour_key = now.strftime("%Y-%m-%d %H")

        # METAR كل ساعة عند :00 (نافذة تسامح أول 5 دقائق)
        if now.minute < 5 and self._last_metar_hour != hour_key:
            generate_metar_for_latest(scheduled_at_utc=now.replace(minute=0, second=0).isoformat())
            self._last_metar_hour = hour_key

        # SYNOP كل 3 ساعات في الأوقات القياسية
        hh = now.strftime("%H")
        if hh in SYNOP_TIMES and now.minute < 5 and self._last_synop_hour != hour_key:
            generate_synop_for_latest(scheduled_at_utc=now.replace(minute=0, second=0).isoformat())
            self._last_synop_hour = hour_key

        # التقرير المناخي اليومي عند 00:05 UTC لليوم السابق
        if now.strftime("%H:%M") == "00:05" and self._last_daily_date != now.strftime("%Y-%m-%d"):
            yesterday = (now - timedelta(days=1)).strftime("%Y-%m-%d")
            generate_daily_report_for(yesterday, scheduled_at_utc=now.isoformat())
            self._last_daily_date = now.strftime("%Y-%m-%d")
